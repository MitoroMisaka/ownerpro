<template>
    <el-card shadow="hover" class="search">
        <el-row class="main_frame_work">
            <el-col class="refine_area">
                <h2>Refine by:</h2>
                <div>
                    <p class="refine_item">Years</p>
                    <el-checkbox class="all_check_item" :indeterminate="years.yearIsIndeterminate" v-show="years.done" v-model="years.yearCheckAll" @change="yearHandleCheckAllChange">全选</el-checkbox>
                    <el-checkbox-group class="check_group" v-model="years.checkedYears" @change="yearHandleCheckedChange">
                      <div>
                        <template v-for="(item, index) in years.yearCnts">
                          <el-checkbox v-show="!years.yearShowMore" class="check_item" :label="item.year" v-if="index < 4" :key="index">{{item.year}}({{item.cnt}})</el-checkbox>
                        </template>
                      </div>
                      <div>
                        <template v-for="(item, index) in years.yearCnts">
                          <el-checkbox v-show="years.yearShowMore" class="check_item" :label="item.year" :key="index">{{item.year}}({{item.cnt}})</el-checkbox>
                        </template>
                      </div>
                      <div v-if="years.yearCnts.length > 4">
                        <div class="more_check_item" v-show="!years.yearShowMore" @click="ShowMoreYear">更多>></div>
                        <div class="more_check_item" v-show="years.yearShowMore" @click="ShowMoreYear">^收回</div>
                      </div>
                    </el-checkbox-group>
                    <p class="refine_item">Sorted by</p>
                    <div>
                      <el-radio-group class="check_group" v-model="Sorts.sortedByCode" @change="ChangeSortedBy">
                        <el-radio class="check_item" :label="1">时间</el-radio>
                        <el-radio class="check_item" :label="2">笔记id</el-radio>
                      </el-radio-group>
                      <el-radio-group class="check_group" v-model="Sorts.orderedByCode" @change="ChangeOrderedBy">
                        <el-radio class="check_item" :label="1">降序</el-radio>
                        <el-radio class="check_item" :label="2">升序</el-radio>
                      </el-radio-group>
                    </div>
                </div>
            </el-col>
            <el-col class="result_area">
                <div class="text_item" v-for="item in Notes.NoteList" :key="item.id">
                    <el-card class="box-card" v-if="years.checkedYears.indexOf(item.year) !== -1">
                      <el-row class="text_row">
                        <el-col :span="16">
                          <div>
                            <i class="el-icon-user"></i>
                            <span class="author" @click="ToMD(item.note_id)"> {{item.publisher}} </span>
                            <br>
                            <i class="el-icon-time"></i>
                            <span class="date"> {{item.publish_time}} </span>
                            <br>
                            <i class="el-icon-collection"></i>
                            <span class="content">{{item.content.substring(0,100)}}</span>
                          </div>
                        </el-col>
                        <el-col :span="2">
                          <el-button type="primary" round size="mini" @click="UpdateNote(item.note_id)">更新笔记</el-button>
                        </el-col>
                        <el-col :span="2">
                          <el-button type="danger" round size="mini" @click="DeleteNote(item.note_id)">删除笔记</el-button>
                        </el-col>
                      </el-row>
                    </el-card>
                </div>
                <div class="block">
                  <el-pagination
                    @size-change="handleSizeChange"
                    @current-change="handleCurrentChange"
                    :current-page="queryInfo.pagenum"
                    :page-sizes="[5, 9, 13, 15]"
                    :page-size="queryInfo.pageSize"
                    layout="total, sizes, prev, pager, next, jumper"
                    :total="Notes.total">
                  </el-pagination>
                </div>
            </el-col>
        </el-row>
    </el-card>
</template>

<script>
export default {
  name: 'NormalSearchResult',
  data () {
    return {
      queryInfo: {
        article_id: 0,
        pageSize: 13,
        pageNum: 1,
        orderBy: 'publish_time desc'
      },
      Notes: {
        NoteList: [],
        total: 0
      },
      Results: ' Results',
      Result: ' Result',
      Sorts: {
        sortedByCode: 1,
        sortedBy: 'publish_time',
        orderedByCode: 1,
        orderedBy: 'desc'
      },
      years: {
        yearCnts: [],
        checkedYears: [],
        yearShowMore: false,
        yearCheckAll: true,
        yearOption: [],
        yearIsIndeterminate: false,
        done: false
      }
    }
  },
  created() {
    window.myData = this
    this.queryInfo.article_id = this.$store.state.ArticleId
    this.GetNoteList()
  },
  methods: {
    GetNoteList() {
      this.queryInfo.orderBy = this.Sorts.sortedBy + ' ' + this.Sorts.orderedBy
      this.$api.note.GetAllNote(this.queryInfo).then(res => {
        this.$message.success('搜索成功!')
        this.Notes.NoteList = res.items
        this.Notes.total = res.total
        this.GetYears()
      })
    },
    ChangeSortedBy() {
      if (this.Sorts.sortedByCode === 1) {
        this.Sorts.sortedBy = 'publish_time'
      } else if (this.Sorts.sortedByCode === 2) {
        this.Sorts.sortedBy = 'note_id'
      }
      this.GetNoteList()
    },
    ChangeOrderedBy() {
      if (this.Sorts.orderedByCode === 1) {
        this.Sorts.orderedBy = 'desc'
      } else if (this.Sorts.orderedByCode === 2) {
        this.Sorts.orderedBy = 'asc'
      }
      this.GetNoteList()
    },
    ToMDtest(url) {
      this.$store.dispatch('savepdfUrl', url)
      this.$router.push('/mdviewtest')
    },
    ToMD(NoteId) {
      this.$store.dispatch('saveNoteId', NoteId)
      this.$router.push('/ViewNote')
    },
    GetYears() {
      this.years.yearCnts.length = 0
      this.years.yearOption.length = 0
      for (let i = 0; i < this.Notes.NoteList.length; i++) {
        const Note = this.Notes.NoteList[i]
        const date = new Date(Note.publish_time)
        const year = date.getFullYear()
        this.Notes.NoteList[i].year = year
        let flag = 0
        for (let j = 0; j < this.years.yearCnts.length; j++) {
          if (this.years.yearCnts[j].year === year) {
            this.years.yearCnts[j].cnt++
            flag = 1
            break
          }
        }
        if (flag === 0) {
          this.years.yearCnts.push({ year: year, cnt: 1 })
          this.years.yearOption.push(year)
        }
      }
      this.years.done = true
      this.years.checkedYears = this.years.yearOption
    },
    ShowMoreYear() {
      this.years.yearShowMore = !this.years.yearShowMore
    },
    yearHandleCheckAllChange(val) {
      this.years.checkedYears = val ? this.years.yearOption : []
      this.years.yearIsIndeterminate = false
    },
    yearHandleCheckedChange(val) {
      this.years.checkedYears = val
      const checkedCount = val.length
      this.years.yearCheckAll = checkedCount === this.years.yearOption.length
      this.years.yearIsIndeterminate = checkedCount > 0 && checkedCount < this.years.yearOption.length
    },
    // 监听 pagesize 改变事件 每页显示的个数
    handleSizeChange(newSize) {
      this.queryInfo.pageSize = newSize
      this.GetNoteList()
    },
    // 监听 页码值 改变的事件 当前页面值
    handleCurrentChange(newPage) {
      this.queryInfo.pageNum = newPage
      this.GetNoteList()
    },
    DeleteNote(NoteId) {
      this.$api.note.DeleteNote(NoteId).then(res => {
        if (res.status !== 0) {
          return this.$message.error('删除失败')
        }
        this.$message.success('删除成功')
        this.GetNoteList()
      })
    },
    UpdateNote(ArticleId) {
      this.$store.dispatch('saveNoteId', ArticleId)
      this.$store.dispatch('saveOperation', 'Update')
      this.$router.push('/UpdateNote')
    }
  }
}
</script>

<style lang="less" scoped>

.main_frame_work {
  margin-top: 20px;
  margin-left: 30px;
  margin-right: 30px;
  .refine_area {
    margin-top: 20px;
    width: 16%;
    .refine_item {
      margin-top: 18px;
      font-size: 16px;
      font-weight: 700;
    }
    .all_check_item {
      margin-top: 6px;
    }
    .check_group {
      margin-top: 4px;
      .check_item {
        margin-top: 6px;
      }
      .more_check_item {
        margin-top: 6px;
        font-size: 14px;
      }
    }
  }
  .result_area {
    width: 82%;
    margin-left: 2%;
    .text_item {
      .box-card {
        margin-bottom: 5px;
        .text_row {
          .el-icon-user {
            font-size: 170%;
            color: #943b00;
            margin-right: 5px;
          }
          .author {
            font-family: 'Times New Roman', Times, serif;
            font-size: 24px;
            font-weight: 700;
            margin-top: 5px;
          }
          .el-icon-time {
            font-size: 120%;
            margin-right: 4px;
            color: rgb(13, 77, 0);
          }
          .date {
            font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            font-size: 14px;
            margin-top: 5px;
          }
          .el-icon-collection {
            font-size: 120%;
            margin-right: 4px;
            color: rgb(0, 24, 77);
          }
          .content {
            font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            font-size: 15px;
            margin-top: 10px;
          }
        }
        .title {
          font-family: 'Times New Roman', Times, serif;
          font-size: 20px;
          font-weight: 700;
        }
      }
    }
  }
}
</style>
