/**
 * user模块接口列表
 */

import base from './base' // 导入接口域名列表
import axios from '@/utils/http' // 导入http中创建的axios实例
import qs from 'qs' // 根据需求是否导入qs模块

const pdf = {
  GetAllRef () {
    return axios.get(`${base.backdev}/article/get_all_reference`)
  },
  AddRef(params) {
    return axios.post(`${base.backdev}/article/add_reference`, params)
  },
  PostPDF (params) {
    return axios({
      method: 'post',
      url: `/${base.backdev}/file/upload`,
      data: params
    })
  },
  GetMetaArticle (ArticleId) {
    return axios.get(`${base.backdev}/article/get_article_info/`, {
      params: {
        article_id: ArticleId
      }
    })
  },
  AddArticle (params) {
    return axios({
      method: 'post',
      url: `/${base.backdev}/article/addArticle`,
      data: params
    })
  },
  DeleteArticle(ArticleId) {
    let params = { id: ArticleId }
    return axios.post(`${base.backdev}/article/delete_article`, qs.stringify(params))
  },
  UpdateArticle(params) {
    return axios.post(`${base.backdev}/article/update_article`, params)
  },
  GetArea() {
    return axios.get(`${base.backdev}/area/all`)
  }
  // 其他接口…………
}

export default pdf
