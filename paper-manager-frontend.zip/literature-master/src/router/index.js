import Vue from 'vue'
import VueRouter from 'vue-router'
const Login = () => import(/* webpackChunkName: "login_home_welome" */ 'components/login/Login')
const Register = () => import(/* webpackChunkName: "login_home_welome" */ 'components/register/Register')
const Home = () => import(/* webpackChunkName: "login_home_welome" */ 'components/home/Home')
const Welcome = () => import(/* webpackChunkName: "login_home_welome" */ 'components/home/welcome/Welcome')

const Users = () => import(/* webpackChunkName: "Users_Rights_Roles" */ 'components/home/users/Users')

const NormalSearch = () => import(/* webpackChunkName: "Users_Rights_Roles" */ 'components/home/search/NormalSearch')
const AdvancedSearch = () => import(/* webpackChunkName: "Users_Rights_Roles" */ 'components/home/search/AdvancedSearch')
const NormalSearchResult = () => import(/* webpackChunkName: "Users_Rights_Roles" */ 'components/home/search/NormalSearchResult')
const AdvancedSearchResult = () => import(/* webpackChunkName: "Users_Rights_Roles" */ 'components/home/search/AdvancedSearchResult')
const UserCenter = () => import(/* webpackChunkName: "Users_Rights_Roles" */ 'components/home/userCenter/UserCenter')
const PDFView = () => import(/* webpackChunkName: "Users_Rights_Roles" */ 'components/home/pdf/PDFView')
const PDFUpload = () => import(/* webpackChunkName: "Users_Rights_Roles" */ 'components/home/pdf/PDFUpload')
const PDFUpdate = () => import(/* webpackChunkName: "Users_Rights_Roles" */ 'components/home/pdf/PDFUpdate')
const EmailValid = () => import(/* webpackChunkName: "Users_Rights_Roles" */ 'components/register/EmailValid')
const mdviewtest = () => import(/* webpackChunkName: "Users_Rights_Roles" */ 'components/home/md/mdviewtest')
const mdview = () => import(/* webpackChunkName: "Users_Rights_Roles" */ 'components/home/md/mdview')
const AddNote = () => import(/* webpackChunkName: "Users_Rights_Roles" */ 'components/home/note/AddNote')
const UpdateNote = () => import(/* webpackChunkName: "Users_Rights_Roles" */ 'components/home/note/UpdateNote')
const NoteList = () => import(/* webpackChunkName: "Users_Rights_Roles" */ 'components/home/note/NoteList')
const ViewNote = () => import(/* webpackChunkName: "Users_Rights_Roles" */ 'components/home/note/ViewNote')
const EditRef = () => import(/* webpackChunkName: "Users_Rights_Roles" */ 'components/home/pdf/EditRef')
const area = () => import(/* webpackChunkName: "Users_Rights_Roles" */ 'components/home/area/area')

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    redirect: '/Login'
  },
  {
    path: '/Login',
    name: 'index',
    meta: { title: '我是首页' },
    component: Login
  },
  {
    path: '/EmailValid',
    component: EmailValid
  },
  {
    path: '/Register',
    component: Register
  },
  {
    path: '/Home',
    component: Home,
    redirect: '/Welcome',
    children: [
      {
        path: '/Welcome',
        component: Welcome
      },
      {
        path: '/Users',
        component: Users
      },
      {
        path: '/NormalSearch',
        component: NormalSearch
      },
      {
        path: '/AdvancedSearch',
        component: AdvancedSearch
      },
      {
        path: '/NormalSearchResult',
        component: NormalSearchResult
      },
      {
        path: '/AdvancedSearchResult',
        component: AdvancedSearchResult
      },
      {
        path: '/UserCenter',
        component: UserCenter
      },
      {
        path: '/PDFView',
        component: PDFView
      },
      {
        path: '/PDFUpload',
        component: PDFUpload
      },
      {
        path: '/mdviewtest',
        component: mdviewtest
      },
      {
        path: '/mdview',
        component: mdview
      },
      {
        path: '/AddNote',
        component: AddNote
      },
      {
        path: '/ViewNote',
        component: ViewNote
      },
      {
        path: '/NoteList',
        component: NoteList
      },
      {
        path: '/PDFUpdate',
        component: PDFUpdate
      },
      {
        path: '/UpdateNote',
        component: UpdateNote
      },
      {
        path: '/EditRef',
        component: EditRef
      },
      {
        path: '/area',
        component: area
      }
    ]
  }
]
const router = new VueRouter({
  mode: 'history',
  routes
})

router.beforeEach((to, from, next) => {
  // to 将访问哪一个路径
  // from 代表从哪个路径跳转而来
  // next 是一个函数,表示放行
  //   next() 放行 next('/login') 强制跳转
  // if (to.path === '/login' || to.path === '/EmailValid' || to.path === '/register') return next()
  // // 获取token
  // const token = window.sessionStorage.getItem('token')
  // console.log(token)
  // if (!token) return next('/login')
  if (to.meta.title) { // 判断是否有标题
    document.title = to.meta.title
  }
  next()
})

export default router
