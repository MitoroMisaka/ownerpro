<template>
  <div>
    <el-card shadow="hover">
      <div class="user">
        <img :src="userInfo.avatar" />
        <div class="userinfo">
          <p class="name">{{ userInfo.name }}</p>
          <p class="subinfo">用户名：{{ userInfo.username }}</p>
          <p class="subinfo">账号类型：{{ userInfo.type }}</p>
        </div>
      </div>
      <div class="other_info">
        <div class="row">
          <span class="title">拥有权限：</span>
          <el-tag class="tag" v-if="userInfo.type === '管理员' || userInfo.add === 1" type="success">增加权限</el-tag>
          <el-tag class="tag" v-if="userInfo.type === '管理员' || userInfo.delete === 1" type="danger">删除权限</el-tag>
          <el-tag class="tag" v-if="userInfo.type === '管理员' || userInfo.update === 1">修改权限</el-tag>
          <el-tag class="tag" v-if="userInfo.type === '管理员' || userInfo.select === 1" type="warning">查询权限</el-tag>
        </div>
        <div class="row">
          <span class="title" v-show="!IsChangePassword">用户操作：</span>
          <el-button class="button" v-show="!IsChangePassword" type="primary" plain round @click="ChangePassword">修改密码</el-button>
          <el-input class="input" v-show="IsChangePassword" type="password" v-model="Newpsd" placeholder="请输入新密码"></el-input>
          <el-button class="button" v-show="IsChangePassword" type="primary" plain round @click="TrueChangePassword">确认修改</el-button>
          <el-button class="button" v-show="IsChangePassword" type="danger" plain round @click="CancelChangePassword">取消修改</el-button>
        </div>
      </div>
    </el-card>
  </div>
</template>

<script>
export default {
  name: 'UserCenter',
  data () {
    return {
      userImg: require('../../../assets/logo.png'),
      Newpsd: '',
      IsChangePassword: false,
      userInfo: {
      }
    }
  },
  created() {
    this.GetInfo()
  },
  methods: {
    GetInfo() {
      this.$api.user.GetInfo().then(res => {
        if (res.status !== 0) {
          return this.$message.error('获取个人信息失败')
        }
        this.$message.success('获取个人信息成功')
        this.userInfo = res.data
      })
    },
    ChangePassword() {
      this.IsChangePassword = true
    },
    TrueChangePassword() {
      this.$api.user.CheckSamePassword(this.Newpsd).then(res => {
        if (res.status !== 0) {
          return this.$message.error('检查密码失败')
        }
        this.$message.success('检查密码成功')
        console.log(this.Newpsd)
        this.$api.user.ChangePassword(this.Newpsd).then(res => {
          if (res.status !== 0) {
            console.log(this.Newpsd)
            return this.$message.error('修改密码失败')
          }
          this.$message.success('修改密码成功')
        })
      })
    },
    CancelChangePassword() {
      this.IsChangePassword = false
    }
  }
}
</script>

<style lang="less" scoped>
  .user {
    display: flex;
    align-items: center;
    padding-bottom: 20px;
    margin-bottom: 20px;
    border-bottom: 1px solid #ccc;
    img {
      width: 150px;
      height: 150px;
      border-radius: 50%;
      margin-right: 40px;
    }
    .userinfo {
      .name {
        font-size: 36px;
        margin-bottom: 10px;
      }
      .subinfo {
        font-size: 15px;
        color: #666666;
      }
    }
  }
  .other_info {
    .row {
      margin-top: 20px;
      .title {
        font-size: 15px;
        color: #666666;
        margin-right: 10px;
      }
      .tag {
        font-size: 15px;
        margin-left: 10px;
      }
      .input {
        margin-top: 10px;
        width: 200px;
      }
      .button {
        margin-top: 10px;
        margin-left: 20px;
      }
    }
  }
</style>
