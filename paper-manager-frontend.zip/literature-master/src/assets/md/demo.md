| VERSION | CONTENT           | AUTHOR | DATE       |
| ------- | ----------------- | ------ | ---------- |
| V0.1    | Born              | 李帅   | 2022/01/20 |
| V0.2    | Fix Search Record | 廖晋川 | 2022/02/22 |



# DATABASE DESIGN

## user 用户

存储用户信息

| Field        | FieldName   | Type    | Bind | Remark         |
| ------------ | ----------- | ------- | ---- | -------------- |
| 用户id       | id          | long    | PK   |                |
| 剧圈号       | junQuanNum  | varchar | FK   |                |
| 会话id       | sessionId   | varchar |      | unique         |
| 用户唯一标识 | openId      | varchar |      | unique         |
| unionid      | unionId     | varchar |      | 暂时用不到     |
| 会话密钥     | sessionKey  | varchar |      |                |
| 创建时间     | createTime  | varchar |      |                |
| 昵称         | nickname    | varchar |      |                |
| 性别         | gender      | int     |      | 1=女，0=男     |
| 学校认证Id   | schoolId    | long    |      |                |
| 公司认证id   | companyId   | long    |      |                |
| 总笔记获赞数 | allLikes    | int     |      |                |
| 关注用户数   | followNum   | int     |      |                |
| 粉丝数       | followerNum | int     |      |                |
| 笔记数       | noteNum     | int     |      |                |
| 头像         | portrait    | varchar |      | 图片地址或序号 |
| tag1         | tag1        | varchar |      |                |
| tag2         | tag2        | varchar |      |                |
| tag3         | tag3        | varchar |      |                |

<br><br>

## schoolCertification 学校认证

通过学校认证的用户

| Field      | Field name | Type     | Bind | Remark                      |
| ---------- | ---------- | -------- | ---- | --------------------------- |
| Id         | id         | long     | PK   |                             |
| 用户剧圈号 | juQuanNum  | varchar  |      |                             |
| 真实姓名   | name       | varchar  |      |                             |
| 学校       | school     | varchar  |      |                             |
| 专业       | major      | datetime |      |                             |
| 年级       | grade      | varchar  |      |                             |
| 学号       | studentId  | varchar  |      |                             |
| 状态       | status     | int      |      | 审核中/已通过/已拒绝:0,1,-1 |

<br><br>

## companyCertification 公司认证

通过公司认证的用户

| Field      | Field name | Type    | Bind | Remark                      |
| ---------- | ---------- | ------- | ---- | --------------------------- |
| Id         | id         | long    | PK   |                             |
| 用户剧圈号 | juQuanNum  | varchar |      |                             |
| 真实姓名   | name       | varchar |      |                             |
| 公司名称   | firmName   | varchar |      |                             |
| 部门       | department | varchar |      |                             |
| 工号       | staffNum   | varchar |      |                             |
| 状态       | status     | int     |      | 审核中/已通过/已拒绝:0,1,-1 |

<br><br>

## note 笔记

| Field      | Field name  | Type     | Bind | Remark |
| ---------- | ----------- | -------- | ---- | ------ |
| Id         | id          | long     | PK   |        |
| 标题       | titile      | varchar  |      |        |
| 用户剧圈号 | juQuanNum   | varchar  |      |        |
| 剧本id     | scriptId    | long     |      |        |
| 店铺id     | storeId     | long     |      |        |
| 发布日期   | publishDate | datetime |      |        |
| 内容       | content     | varchar  |      |        |
| 点赞数     | likes       | int      |      |        |
| 评论数     | comments    | int      |      |        |
| 收藏数     | collections | int      |      |        |
| 浏览次数   | browse      | int      |      |        |

<br><br>

## order 订单

可自己发起，可在拼车广场看到

| Field        | Field name  | Type     | Bind | Remark            |
| ------------ | ----------- | -------- | ---- | ----------------- |
| Id           | id          | long     | PK   |                   |
| 发车人剧圈号 | driverNum   | varchar  |      |                   |
| 状态         | status      | int      |      | 0:拼车中 1:发车了 |
| 整车人数     | finalPeople | int      |      |                   |
| 人数         | people      | int      |      |                   |
| 订单发出时间 | publishTime | datetime |      |                   |
| 发车时间     | driveTime   | datetime |      |                   |
| 剧本id       | scriptId    | varchar  |      |                   |
| 店铺id       | storeId     | varchar  |      |                   |

<br><br>

## script 剧本

| Field     | Field name  | Type    | Bind | Remark         |
| --------- | ----------- | ------- | ---- | -------------- |
| Id        | id          | long    | PK   |                |
| 剧本名    | name        | varchar |      |                |
| 类型      | types       | varchar |      |                |
| 特征      | traits      | varchar |      |                |
| 想玩人数  | playNum     | int     |      |                |
| 大V推荐度 | recommend   | int     |      | 百分数         |
| 评分      | score       | double  |      |                |
| 评分人数  | commentNum  | int     |      |                |
| 详情      | content     | varchar |      |                |
| 点赞数    | likes       | int     |      |                |
| 收藏数    | collections | int     |      |                |
| 浏览次数  | browse      | int     |      |                |
| 图片      | picture     | varchar |      | 图片地址或序号 |

<br><br>

## score 店铺

| Field name | Field       | Type    | Bind | Remark         |
| ---------- | ----------- | ------- | ---- | -------------- |
| Id         | id          | bigint  | PK   |                |
| 店铺名称   | name        | varchar |      |                |
| 位置       | loction     | varchar |      |                |
| 电话       | telephone   | varchar |      |                |
| 想玩人数   | playNum     | int     |      |                |
| 大V推荐度  | recommend   | int     |      | 百分数         |
| 评分       | score       | double  |      |                |
| 评分人数   | commentNum  | int     |      |                |
| 详情       | content     | varchar |      |                |
| 点赞数     | likes       | int     |      |                |
| 收藏数     | collections | int     |      |                |
| 浏览次数   | browse      | int     |      |                |
| 图片       | picture     | varchar |      | 图片地址或序号 |

<br><br>

## relation 店铺中剧本

| Field  | Field name | Type | Bind | Remark |
| ------ | ---------- | ---- | ---- | ------ |
| Id     | id         | long | PK   |        |
| 店铺id | storeId    | long |      |        |
| 剧本id | scriptId   | long |      |        |

<br><br>

## message 消息

所有用户的实时聊天消息

| Field    | Field name  | Type     | Bind | Remark |
| -------- | ----------- | -------- | ---- | ------ |
| Id       | id          | long     | PK   |        |
| 发出用户 | senderNum   | varchar  |      |        |
| 接受用户 | receiverNum | varchar  |      |        |
| 发送时间 | sendTime    | datetime |      |        |
| 是否已读 | isRead      | bool     |      |        |

<br><br>

## follow 关注

| Field    | Field name  | Type     | Bind | Remark |
| -------- | ----------- | -------- | ---- | ------ |
| Id       | id          | long     | PK   |        |
| 关注者   | followerNum | varchar  |      |        |
| 被关注者 | followedNum | varchar  |      |        |
| 关注时间 | followTime  | datetime |      |        |

<br><br>

## collection 收藏

| Field      | Field name  | Type     | Bind | Remark                   |
| ---------- | ----------- | -------- | ---- | ------------------------ |
| id         | id          | bigint   | PK   |                          |
| 对象类型   | type        | varchar  |      | 笔记/店铺/剧本：enum约束 |
| 对象id     | objectId    | long     |      |                          |
| 用户剧圈号 | juQuanNum   | varchar  |      |                          |
| 收藏时间   | collectTime | datetime |      |                          |

<br><br>

## likes点赞

| Field      | Field name | Type     | Bind | Remark                   |
| ---------- | ---------- | -------- | ---- | ------------------------ |
| id         | id         | bigint   | PK   |                          |
| 对象类型   | type       | varchar  |      | 笔记/店铺/剧本：enum约束 |
| 对象id     | objectId   | long     |      |                          |
| 用户剧圈号 | juQuanNum  | varchar  |      |                          |
| 点赞时间   | likeTime   | datetime |      |                          |

<br><br>

## comment 评论

| Field      | Field name  | Type     | Bind | Remark |
| ---------- | ----------- | -------- | ---- | ------ |
| id         | id          | bigint   | PK   |        |
| 笔记id     | objectId    | long     |      |        |
| 用户剧圈号 | juQuanNum   | varchar  |      |        |
| 评论时间   | commentTime | datetime |      |        |
| 评论内容   | content     | varchar  |      |        |
| 评论点赞数 | likes       | int      |      |        |

<br>

<br>

## search_term 搜索推荐

| Field  | FieldName | Type    | Bind | Remark |
| ------ | --------- | ------- | ---- | ------ |
| id     | id        | long    | PK   |        |
| 搜索名 | name      | varchar |      |        |
| 点击量 | hits      | int     |      |        |

<br>

<br>

## search_history 搜索历史

| Field      | FieldName  | Type    | Bind | Remark |
| ---------- | ---------- | ------- | ---- | ------ |
| id         | id         | long    | PK   |        |
| 用户剧圈号 | juQuanNum  | varchar |      |        |
| 搜索名     | name       | varchar |      |        |
| 搜索时间   | searchTime | varchar |      |        |

<br>

<br>

## hot_topic 热门话题

| Field      | Field name | Type     | Bind | Remark                   |
| ---------- | ---------- | -------- | ---- | ------------------------ |
| id         | id         | bigint   | PK   |                          |
| 话题类型   | type       | varchar  |      | 笔记/店铺/剧本：enum约束 |
| 话题标题   | title      | varchar  |      |                          |
| 话题链接id | objectId   | varchar  |      |                          |
| 点赞时间   | likeTime   | datetime |      |                          |