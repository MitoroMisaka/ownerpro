<template>
  <div class="main">
    <div class="meta">
      <div class="title">{{ Articles.title }}</div>
      <div class="arthor"> {{ writter }} </div>
      <el-row class="content">
        <span class="subtitle">摘要：</span>
        <span class="subcontent">{{ Articles.abstract_content }}</span>
      </el-row>
      <div class="content">
        <span class="subtitle">关键词：</span>
        <span class="subcontent">{{ keyword }}</span>
      </div>
      <div class="content">
        <span class="subtitle">专题：</span>
        <span class="subcontent">{{ area }}</span>
        </div>
    </div>
    <div class="pdf">
      <el-row>
        <el-col :span="16" class="button_left">
          <el-button-group>
            <el-button type="primary" icon="el-icon-arrow-left" @click="prePage">上一页</el-button>
            <el-button type="primary" @click="nextPage">下一页<i class="el-icon-arrow-right el-icon--right"></i></el-button>
          </el-button-group>
        </el-col>
        <el-col :span="8" class="button_right">
          <el-button type="success" @click="ToRef">编辑引用</el-button>
          <el-button type="warning" @click="ToNote">记笔记</el-button>
          <el-button type="primary" @click="ToNoteList">查看笔记</el-button>
        </el-col>
      </el-row>
      <div style="marginTop: 10px; color: #409EFF">{{ pageNum }} / {{ pageTotalNum }}</div>
      <pdf
        :page="pageNum"
        :src="url"
        @progress="loadedRatio = $event"
        @num-pages="pageTotalNum=$event"
        ></pdf>
    </div>
  </div>
</template>

<script>
import pdf from 'vue-pdf'
export default {
  name: 'PDFView',
  components: {
    pdf
  },
  data() {
    return {
      url: '',
      pageNum: 1,
      pageTotalNum: 1,
      loadedRatio: 0,
      Articles: {

      },
      writter: '',
      keyword: '',
      area: ''
    }
  },
  created() {
    window.myData = this
    this.ArticleId = this.$store.state.ArticleId
    this.url = '/api/' + this.$store.state.pdfUrl
    this.url = pdf.createLoadingTask(this.url)
    this.GetMetaArticle()
  },
  methods: {
    GetMetaArticle () {
      this.$api.markdown.GetMetaArticle(this.ArticleId).then(res => {
        this.$message.success('获取元数据成功')
        this.Articles = res
        this.ToString()
      })
    },
    ToString () {
      this.writter = this.Articles.writer[0]
      this.keyword = this.Articles.keyword[0]
      this.area = this.Articles.area[0]
      for (let i = 1; i < this.Articles.writer.length; i++) {
        this.writter = this.writter + ', ' + this.Articles.writer[i]
      }
      for (let i = 1; i < this.Articles.area.length; i++) {
        this.area = this.area + ', ' + this.Articles.area[i]
      }
      for (let i = 1; i < this.Articles.keyword.length; i++) {
        this.keyword = this.keyword + ', ' + this.Articles.keyword[i]
      }
    },
    // 上一页
    prePage() {
      let page = this.pageNum
      page = page > 1 ? page - 1 : this.pageTotalNum
      this.pageNum = page
    },
    // 下一页
    nextPage() {
      let page = this.pageNum
      page = page < this.pageTotalNum ? page + 1 : 1
      this.pageNum = page
    },
    ToNote() {
      this.$router.push('/AddNote')
    },
    ToNoteList() {
      this.$router.push('/NoteList')
    },
    ToRef() {
      this.$router.push('/EditRef')
    }
  }
}
</script>

<style lang="less" scoped>
.main {
  margin-left: 40px;
  margin-right: 40px;
  .meta {
    .title {
      margin-top: 30px;
      text-align: center;
      font-size: 32px;
      color: #000;
      font-weight: 700;
    }
    .arthor {
      margin-top: 20px;
      text-align: center;
      font-size: 20px;
      color: #646464;
      font-weight: 400;
    }
    .content {
      margin-top: 14px;
      .subtitle {
        text-align: left;
        font-size: 16px;
        color: #000;
        font-weight: 700;
      }
      .subcontent {
        text-align: left;
        font-size: 16px;
        color: #646464;
        font-weight: 400;
        line-height: 2.0;
      }
    }
  }
  .pdf {
    margin-top: 40px;
    .button_left {
      text-align: left;
    }
    .button_right {
      text-align: right;
    }
  }
}
</style>
