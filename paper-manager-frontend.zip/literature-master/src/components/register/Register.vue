<template>
  <div class="login_container">
    <div class="login_box">
      <!--      头像区域-->
      <div class="avatar_box">
        <img src="~assets/logo.png" alt="" />
      </div>
      <!--      表单提交区域-->
      <el-form :rules="registerFormRules" ref="registerFormRef" label-width="0px" class="register_form" :model="registerForm">
        <!--        用户名-->
        <el-form-item prop="username">
          <el-input v-model="registerForm.username" placeholder="请输入用户名" prefix-icon="iconfont icon-user"></el-input>
        </el-form-item>
        <!--        昵称-->
        <el-form-item prop="name">
          <el-input v-model="registerForm.name" placeholder="请输入昵称" prefix-icon="iconfont icon-user"></el-input>
        </el-form-item>
        <!--        密码-->
        <el-form-item prop="password">
          <el-input type="password" v-model="registerForm.password" placeholder="请输入密码" prefix-icon="iconfont icon-3702mima"></el-input>
        </el-form-item>
        <!--        按钮区-->
        <el-form-item class="btns">
          <el-button type="primary" @click="register" :loading="registerLoading">注册</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>

<script>
import { userAddFormRulesMixin } from '@/common/mixin.js'
export default {
  name: 'EmailValid',
  mixins: [userAddFormRulesMixin],
  data() {
    return {
      registerLoading: false, // 登录限制
      registerForm: {
        // 注册的表单数据的绑定对象
        username: '',
        name: '',
        password: ''
      }
    }
  },
  created() {
    window.myData = this
  },
  methods: {
    register() {
      this.registerLoading = true
      this.$refs.registerFormRef.validate(valid => {
        if (!valid) {
          return (this.loginLoading = false)
        }
        this.$api.user.Register(this.registerForm).then(res => {
          if (res.status !== 0) {
            this.loginLoading = false
            return this.$message.error('登录失败 帐号或密码错误!')
          }
          this.$message.success('登录成功!')
          window.sessionStorage.setItem('token', res.data.token)
          this.$router.push('/home')
          this.loginLoading = false
        })
      })
    }
  }
}
</script>

<style lang="less" scoped>
.login_container {
  height: 100%;
  background-color: #66ccff;
}
.login_box {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 450px;
  height: 350px;
  background-color: #fff;
  border-radius: 3px;
  .avatar_box {
    position: absolute;
    left: 50%;
    transform: translate(-50%, -50%);
    padding: 10px;
    width: 130px;
    height: 130px;
    border: 1px solid #eee;
    border-radius: 50%;
    box-shadow: 0 0 10px #ddd;
    background-color: #fff;
    img {
      width: 100%;
      height: 100%;
      border-radius: 50%;
      background-color: #eeeeee;
    }
  }
  .register_form {
    box-sizing: border-box;
    position: absolute;
    bottom: 0;
    width: 100%;
    padding: 0 20px;
    .time{
      margin-left: -20px;
    }
  }
  .btns {
    display: flex;
    justify-content: flex-end;
  }
}
</style>
