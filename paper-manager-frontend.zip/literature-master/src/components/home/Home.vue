<template>
  <el-container class="home-container">
    <!-- 头部区域 -->
    <el-header>
      <div>
        <span>文献管理系统</span>
      </div>
      <el-dropdown trigger="click" size="mini">
        <span>
          <img src="~assets/manager.jpg" alt="" />
        </span>
        <el-dropdown-menu slot="dropdown">
          <el-dropdown-item @click.native="ToUesrCenter">个人中心</el-dropdown-item>
          <el-dropdown-item @click.native="logout">退出</el-dropdown-item>
        </el-dropdown-menu>
      </el-dropdown>
    </el-header>
    <el-container>
      <!-- 侧边栏 -->
      <el-aside :width="isCollapse ? '61px' : '200px'">
        <!-- <el-radio-group class="toggle-button" @click="toggleCollpase" v-model="isCollapse" style="margin-bottom: 20px;">
          <el-radio-button :label="false">展开</el-radio-button>
          <el-radio-button :label="true">收起</el-radio-button>
        </el-radio-group> -->
        <!-- 侧边栏菜单区域 -->
        <el-menu
          text-color="#000"
          active-text-color="#409EFF"
          class="el-menu-vertical-demo"
          :default-active="activePath"
          :unique-opened="true"
          :collapse="isCollapse"
          :collapse-transition="false"
          :router="true"
          @open="handleOpen"
          @close="handleClose"
        >
          <!-- 一级菜单 -->
          <el-menu-item v-for="item in noChildren" :index="item.path + ''" :key="item.path" @click="saveActivePath(item.path)">
            <i :class="'el-icon-' + item.icon"></i>
            <span slot="title">{{item.label}}</span>
          </el-menu-item>
          <!-- 二级菜单 -->
          <el-submenu v-for="item in hasChildren" :index="item.label + ''" :key="item.label">
            <template slot="title">
                <i :class="'el-icon-' + item.icon"></i>
                <span slot="title">{{item.label}}</span>
            </template>
            <el-menu-item-group v-for="subItem in item.children" :key="subItem.path">
                <el-menu-item :index="subItem.path + ''" @click="saveActivePath(subItem.path)">
                    <i :class="'el-icon-' + subItem.icon"></i>
                    <span slot="title">{{subItem.label}}</span>
                </el-menu-item>
            </el-menu-item-group>
          </el-submenu>
        </el-menu>
      </el-aside>
      <!-- 右侧内容主题 -->
      <el-main>
        <!-- 路由占位符 -->
        <router-view></router-view>
      </el-main>
    </el-container>
  </el-container>
</template>

<script>
import UserCenterVue from './userCenter/UserCenter.vue'
export default {
  name: 'Home',
  data() {
    return {
      // 左侧菜单数据
      menuList: [
        {
          path: '/Welcome',
          name: 'Welcome',
          label: '欢迎',
          icon: 's-home',
          url: 'welcome/Welcome'
        },
        {
          path: '/Users',
          name: 'Users',
          label: '用户管理',
          icon: 'user',
          url: 'users/Users'
        },
        {
          path: '/area',
          name: 'area',
          label: '研究领域',
          icon: 'collection',
          url: 'welcome/Welcome'
        },
        {
          label: '搜索',
          icon: 'search',
          children: [
            {
              path: '/NormalSearch',
              name: 'NormalSearch',
              label: '按标题搜索',
              icon: 'search',
              url: 'search/NormalSearch'
            },
            {
              path: '/AdvancedSearch',
              name: 'AdvancedSearch',
              label: '筛选搜索',
              icon: 'search',
              url: 'search/AdvancedSearch'
            }
          ]
        }
      ],
      isCollapse: false, // 是否折叠属性
      activePath: '',
      Authority: 0
    }
  },
  created() {
    this.AuthorityInit()
    this.activePath = window.sessionStorage.getItem('activePath')
  },
  methods: {
    logout() {
      this.$api.user.SignOut().then(res => {
        this.$message.success('已登出')
        window.sessionStorage.clear()
        this.$router.push('/login')
      })
    },
    handleOpen(key, keyPath) {
      console.log(key, keyPath)
    },
    handleClose(key, keyPath) {
      console.log(key, keyPath)
    },
    // 点击按钮,切换菜单的折叠和展开
    toggleCollpase() {
      this.isCollapse = !this.isCollapse
    },
    saveActivePath(activePath) {
      window.sessionStorage.setItem('activePath', activePath)
      this.activePath = activePath
      // console.log(this.$route.path)
    },
    ToUesrCenter() {
      this.$router.push('/UserCenter')
    },
    AuthorityInit() {
      this.Authority = this.$store.state.Authority
    }
  },
  computed: {
    noChildren() {
      return this.menuList.filter(item => !item.children)
    },
    hasChildren() {
      return this.menuList.filter(item => item.children)
    }
  }
}
</script>

<style lang="less" scoped>
.hwelcome {
  color: #fff;
  font-size: 15px;
  height: 25px;
  text-align: center;
  background: green;
  span {
    margin-left: 10px;
  }
}
.home-container {
  height: 100%;
}
.el-header {
  display: flex;
  justify-content: space-between;
  padding-left: 0;
  background-color: #252729;
  align-items: center;
  color: #fff;
  font-size: 20px;
  > div {
      display: flex;
      align-items: center;
    }
    span {
      font-size: 25px;
      margin-left: 35px;
    }
    img {
      width: 45px;
      height: 45px;
      border-radius: 50%;
    }
}
.el-aside {
  background-color: #fff;
  .el-menu {
    border-right: none;
  }
}
.toggle-button {
  background: #4a5064;
  font-size: 10px;
  text-align: center;
  line-height: 24px;
  color: #fff;
  letter-spacing: 0.2em;
  cursor: pointer;
}
.el-main {
  background-color: #eaedf1;
}
.iconfont {
  padding-right: 10px;
}

</style>
