<template>
  <div>
    <!-- 引用选择下拉框 -->
    <div class="title">
      <span>所有收录的引用：</span>
      <el-select v-model="referenceRequest.reference_id" placeholder="请选择">
        <el-option
          v-for="item in ReferenceOption"
          :key="item.reference_id"
          :label="item.name"
          :value="item.reference_id">
        </el-option>
      </el-select>
      <br>
      <el-input class="input" v-model="referenceRequest.note" placeholder="请输入你所引用的内容">引用内容：</el-input>
      <el-button type="primary" round @click="AddRef">添加引用</el-button>
    </div>
  </div>
</template>

<script>
export default {
  name: 'ReferenceUpdate',
  data () {
    return {
      noteRequest: {
        article_id: 0,
        content: ''
      },
      ReferenceOption: {
      },
      referenceRequest: {
        article_id: 0,
        reference_id: 0,
        note: ''
      }
    }
  },
  created() {
    window.myData = this
    this.noteRequest.article_id = this.$store.state.ArticleId
    this.GetAllRef()
  },
  methods: {
    GetAllRef() {
      this.$api.pdf.GetAllRef(this.referenceRequest).then(res => {
        this.ReferenceOption = res
      })
    },
    AddRef() {
      this.$api.pdf.AddRef(this.referenceRequest).then(res => {
        if (res.status !== 0) {
          return this.$message.error('编辑引用失败')
        }
        this.$message.success('编辑引用成功')
      })
    }
  }
}
</script>

<style lang="less" scoped>
  .title {
    margin-top: 20px;
    font-size: 16px;
    .input {
      width: 300px;
      margin-top: 20px;
      margin-right: 20px;
    }
  }
</style>
