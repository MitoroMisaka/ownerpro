<template>
    <el-card shadow="hover" class="search">
        <div>
            <div class="slogan_vice">
                <span slot="title">Accelerating research discovery to shape a better future</span>
            </div>
            <div class="slogan_main">
                <span slot="title">Today's Reasearch, tomorrow's innovation</span>
            </div>
            <div class="search_content">
                <el-input @keyup.enter.native="Search()" v-model="normalSearchContent" placeholder="Search publications, articles, keywords, etc">
                    <el-button slot="append" icon="el-icon-search" @click="Search()"></el-button>
                </el-input>
            </div>
            <el-row class="guide_line">
              <span class="guide_line_left" @click="ToPDFUpload()">添加文献</span>
              <span class="guide_line_right" @click="ToAdvanced()">按学科搜索</span>
            </el-row>
            <div class="info_group">
                <div class="info_item">
                    <span>100+Journals</span>
                </div>
                <div class="info_item">
                    <span>|</span>
                </div>
                <div class="info_item">
                    <span>20+Reference Works</span>
                </div>
                <div class="info_item">
                    <span>|</span>
                </div>
                <div class="info_item">
                    <span>120+Online Books</span>
                </div>
            </div>
        </div>
    </el-card>
</template>

<script>
export default {
  name: 'NormalSearch',
  data () {
    return {
      normalSearchContent: ''
    }
  },
  methods: {
    ToAdvanced() {
      this.$router.push('/AdvancedSearch')
    },
    ToPDFUpload() {
      this.$router.push('/PDFUpload')
    },
    Search() {
      this.$store.dispatch('saveNormalSearchContent', this.normalSearchContent)
      this.$router.push('/NormalSearchResult')
    }
  }
}
</script>

<style lang="less" scoped>
.search {
  background: url(../../../assets/search_background.jpg) top left / 100% 105% no-repeat;
  .slogan_vice {
    font-size: 40px;
    color: #fff;
    text-align: center;
    margin-top: 70px;
  }
  .slogan_main {
    font-size: 60px;
    color: #fff;
    text-align: center;
    margin-top: 20px;
  }
  .search_content {
    width: 40%;
    margin-left: 30%;
    margin-top: 60px;
  }
  .guide_line {
    font-size: 16px;
    margin-top: 10px;
    color: #fff;
    .guide_line_left {
      margin-left: 30%;
    }
    .guide_line_right {
      margin-left: 31%;
    }
  }
  .info_group {
    display: flex;
    justify-content: space-around;
    margin-top: 70px;
    .info_item {
      color: #fff;
      font-size: 24px;
    }
  }
}
</style>
