/**
 * user模块接口列表
 */

import base from './base' // 导入接口域名列表
import axios from '@/utils/http' // 导入http中创建的axios实例
import qs from 'qs' // 根据需求是否导入qs模块

const search = {
  searchTitle (params) {
    return axios.get(`${base.backdev}/search/title`, {
      params: params
    })
  },
  searchSubject (params) {
    return axios.get(`${base.backdev}/search/by_label`, {
      params: params,
      paramsSerializer: function(params) {
        return qs.stringify(params, { arrayFormat: 'repeat' })
      }
    })
  },
  GetPie(params) {
    return axios.get(`${base.backdev}/statistics/by_label`, {
      params: params
    })
  }
  // 其他接口…………
}

export default search
