// 保存当前菜单栏路径
export const savePath = (state, pathName) => {
  state.pathName = pathName
}

// 保存当前普通搜索内容
export const saveNormalSearchContent = (state, normalSearchContent) => {
  state.normalSearchContent = normalSearchContent
}

// 保存当前高级搜索内容
export const saveAdvancedSearchContent = (state, Advanced) => {
  state.Advanced = Advanced
}

// 保存当前PDF的URL
export const savepdfUrl = (state, pdfUrl) => {
  state.pdfUrl = pdfUrl
}

// 保存当前MarkDown的ArticleId
export const saveArticleId = (state, ArticleId) => {
  state.ArticleId = ArticleId
}

// 保存当前MarkDown的NoteId
export const saveNoteId = (state, NoteId) => {
  state.NoteId = NoteId
}

// 保存当前token
export const savetoken = (state, token) => {
  state.token = token
}

// 保存当前用户名
export const saveUsername = (state, Username) => {
  state.Username = Username
}

// 保存当前昵称
export const saveNickname = (state, Nickname) => {
  state.Nickname = Nickname
}

// 保存当前用户类别
export const saveAuthority = (state, Authority) => {
  state.Authority = Authority
}

// 保存当前对pdf文献的操作
export const saveOperation = (state, Operation) => {
  state.Operation = Operation
}
