<template>
	<div class="main">
		<div class="markdown-body">
			<VueMarkdown :source="mdData" v-highlight></VueMarkdown>
		</div>
		<div class="comment">
      <p class="title">评论：</p>
        <comment
          :commentNum=CommentList.length
          :commentList=CommentList
          @doSend="doSend"
          @doChidSend="doChildSend">
        </comment>
		</div>
	</div>
</template>

<script>
import VueMarkdown from 'vue-markdown'
import comment from 'bright-comment'
export default {
  components: {
    VueMarkdown,
    comment
  },
  data() {
    return {
      mdData: '',
      AuthorName: '',
      GetNoteRequest: {
        note_id: 0
      },
      PostCommentRequest: {
        note_id: 0,
        super_id: 0,
        to_user: '',
        content: ''
      },
      GetCommentRequest: {
        pageNum: 1,
        pageSize: 8,
        orderBy: 'comment_time desc',
        note_id: 0
      },

      // TmpCommentList 是临时变量
      TmpCommentList: [],

      CommentList: [],

      CommentListItem: {
        id: 1,
        commentUser: {
          id: 1,
          nickName: '',
          avatar: ''
        },
        content: '',
        createDate: '2019-9-23 17:36:02',
        childrenList: []
      },

      sub_Comment_item: {
        id: 2,
        commentUser: {
          id: 2,
          nickName: '',
          avatar: ''
        },
        targetUser: {
          id: 1,
          nickName: '',
          avatar: ''
        },
        content: '',
        createDate: '2019-9-23 17:45:26'
      }
    }
  },
  created() {
    window.myData = this
    this.GetNoteRequest.note_id = this.$store.state.NoteId
    this.PostCommentRequest.note_id = this.$store.state.NoteId
    this.GetCommentRequest.note_id = this.$store.state.NoteId
    this.GetNote()
    this.CommentQuery()
  },
  methods: {
    GetNote() {
      this.$api.note.GetNoteById(this.GetNoteRequest).then(res => {
        this.mdData = res.content
        this.AuthorName = res.publisher
      })
    },
    doSend (text) {
      console.log('dosend')
      console.log(text)
      this.PostCommentRequest.content = text
      this.$api.comment.PostComment(this.PostCommentRequest).then(res => {
        if (res.status !== 0) {
          return this.$message.error('评论失败')
        }
        this.$message.success('评论成功')
        this.CommentQuery()
      })
    },
    doChildSend (text, targetUserId, parentId) {
      console.log('dosend')
      console.log(text + targetUserId, parentId)
      this.PostCommentRequest.content = text
      this.PostCommentRequest.to_user = targetUserId
      this.PostCommentRequest.super_id = parentId
      this.$api.comment.PostComment(this.PostCommentRequest).then(res => {
        if (res.status !== 0) {
          return this.$message.error('回复失败')
        }
        this.$message.success('回复成功')
        this.CommentQuery()
      })
    },
    CommentQuery () {
      this.visible = true
      this.$nextTick(() => {
        this.$api.comment.GetComment(this.GetCommentRequest).then(res => {
          this.$message.success('获得评论成功')
          this.TmpCommentList = res.items
          this.TrueCommentList()
        })
      })
    },
    TrueCommentList() {
      this.CommentList.splice(0, this.CommentList.length)

      for (let i = 0; i < this.TmpCommentList.length; i++) {
        this.CommentListItem.id = this.TmpCommentList[i].comment_id

        this.CommentListItem.commentUser.id = this.TmpCommentList[i].user.id
        this.CommentListItem.commentUser.nickName = this.TmpCommentList[i].user.name
        this.CommentListItem.commentUser.avatar = 'http://localhost:8081/1654865814192.jpg'

        this.CommentListItem.content = this.TmpCommentList[i].content
        this.CommentListItem.createDate = this.TmpCommentList[i].comment_time

        this.CommentListItem.childrenList.splice(0, this.CommentListItem.childrenList.length)

        for (let j = 0; j < this.TmpCommentList[i].sub_comment.length; j++) {
          this.sub_Comment_item.id = this.TmpCommentList[i].sub_comment[j].comment_id

          this.sub_Comment_item.commentUser.id = this.TmpCommentList[i].sub_comment[j].name.id
          this.sub_Comment_item.commentUser.nickName = this.TmpCommentList[i].sub_comment[j].name.name
          this.sub_Comment_item.commentUser.avatar = 'http://localhost:8081/1654865814192.jpg'

          this.sub_Comment_item.targetUser.id = this.TmpCommentList[i].sub_comment[j].to_user.id
          this.sub_Comment_item.targetUser.nickName = this.TmpCommentList[i].sub_comment[j].to_user.name
          this.sub_Comment_item.targetUser.avatar = 'http://localhost:8081/1654865814192.jpg'

          this.sub_Comment_item.content = this.TmpCommentList[i].sub_comment[j].content

          this.sub_Comment_item.createDate = this.TmpCommentList[i].sub_comment[j].comment_time

          this.CommentListItem.childrenList.push(JSON.parse(JSON.stringify(this.sub_Comment_item)))
        }

        this.CommentList.push(JSON.parse(JSON.stringify(this.CommentListItem)))
      }
      console.log(this.CommentList[1].childrenList[0].commentUser.nickName)
      console.log(this.CommentList[1].childrenList[0].targetUser.nickName)
    }
  }
}
</script>

<style lang="less" scoped>
  .main {
    border-style: solid;
    border-width: 30px;
    border-color: #fff;
    background-color: #fff;
    .comment {
      margin-top: 30px;
      .title {
        font-size: 24px;
        color: #000;
        font-weight: 700;
      }
    }
  }
</style>
