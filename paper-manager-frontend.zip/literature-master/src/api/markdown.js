/**
 * markdown模块接口列表
 */

import base from './base' // 导入接口域名列表
import axios from '@/utils/http' // 导入http中创建的axios实例
import qs from 'qs' // 根据需求是否导入qs模块
import { post } from 'jquery'

const markdown = {
  // 获取md文件
  GetMD (ArticleId) {
    return axios.get(`${base.backdev}/file/get-file/${ArticleId}`)
  },
  GetMetaArticle (ArticleId) {
    return axios.get(`${base.backdev}/article/get_article_info/`, {
      params: {
        article_id: ArticleId
      }
    })
  },
  // 上传md文件
  postMD (params) {
    return axios({
      method: 'post',
      url: `/${base.backdev}/article/add_note`,
      data: params
    })
  },
  // 上传图片
  uploadFile (params) {
    return axios({
      method: 'post',
      url: `/${base.backdev}/file/upload`,
      data: params
    })
  },
  UpdateNote (params) {
    return axios.post(`/${base.backdev}/article/update_note`, params)
  }
  // 其他接口…………
}

export default markdown
