<template>
  <div class="login_container">
    <div class="login_box">
      <!--      头像区域-->
      <div class="avatar_box">
        <img src="~assets/logo.png" alt="" />
      </div>
      <!--      表单提交区域-->
      <el-form :rules="registerFormRules" ref="registerFormRef" label-width="0px" class="register_form" :model="registerForm">
        <!--        邮箱-->
        <el-form-item prop="email">
          <el-input v-model="registerForm.email" placeholder="请输入邮箱" prefix-icon="el-icon-message">
            <el-button slot="append" class= "time" v-show="showTime" @click="sendEmail()">发送验证码</el-button>
            <el-button slot="append" class= "time" v-show="!showTime" >{{sendTime}}秒后重发</el-button>
          </el-input>
        </el-form-item>
        <!--        验证码-->
        <el-form-item>
          <el-input v-model="registerForm.validNumByUser" placeholder="请输入验证码" prefix-icon="iconfont icon-3702mima"></el-input>
        </el-form-item>
        <!--        按钮区-->
        <el-form-item class="btns">
          <el-button type="primary" @click="register" :loading="registerLoading">验证</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>

<script>
import { userAddFormRulesMixin } from '@/common/mixin.js'
export default {
  name: 'EmailValid',
  mixins: [userAddFormRulesMixin],
  data() {
    return {
      registerLoading: false, // 登录限制
      registerForm: {
        // 注册的表单数据的绑定对象
        email: '',
        validNumByUser: '',
        validNum: ''
      },
      showTime: true, /* 布尔值，通过v-show控制显示‘获取按钮’还是‘倒计时’ */
      sendTime: '', /* 倒计时 计数器 */
      timer: null
    }
  },
  created() {
    window.myData = this
  },
  methods: {
    register() {
      this.registerLoading = true
      if (parseInt(this.registerForm.validNumByUser) === this.registerForm.validNum) {
        this.$message.success('验证成功!')
      } else {
        this.$message.error('验证失败!')
      }
      this.$router.push('/register')
      this.registerLoading = false
    },
    sendEmail() {
      this.$refs.registerFormRef.validate(valid => {
        if (!valid) {
          return (this.registerLoading = false)
        }
        this.$api.user.EmailSend(this.registerForm.email).then(res => {
          if (res.status !== 0) {
            this.loginLoading = false
            return this.$message.error('邮箱格式错误!')
          }
          this.$message.success('已发送验证码!')
          this.registerForm.validNum = res.data
          this.loginLoading = false
        })
        const TIME_COUNT = 6 // 更改倒计时时间
        if (!this.timer) {
          this.sendTime = TIME_COUNT
          this.showTime = false
          // 循环执行
          this.timer = setInterval(() => {
            if (this.sendTime > 0 && this.sendTime <= TIME_COUNT) {
              this.sendTime--
            } else {
              this.showTime = true
              clearInterval(this.timer) // 清除定时器
              this.timer = null
            }
          }, 1000)
        }
      })
    }
  }
}
</script>

<style lang="less" scoped>
.login_container {
  height: 100%;
  background-color: #66ccff;
}
.login_box {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 450px;
  height: 300px;
  background-color: #fff;
  border-radius: 3px;
  .avatar_box {
    position: absolute;
    left: 50%;
    transform: translate(-50%, -50%);
    padding: 10px;
    width: 130px;
    height: 130px;
    border: 1px solid #eee;
    border-radius: 50%;
    box-shadow: 0 0 10px #ddd;
    background-color: #fff;
    img {
      width: 100%;
      height: 100%;
      border-radius: 50%;
      background-color: #eeeeee;
    }
  }
  .register_form {
    box-sizing: border-box;
    position: absolute;
    bottom: 0;
    width: 100%;
    padding: 0 20px;
    .time{
      margin-left: -20px;
    }
  }
  .btns {
    display: flex;
    justify-content: flex-end;
  }
}
</style>
