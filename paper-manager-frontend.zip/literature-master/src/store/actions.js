// 触发保存菜单栏路径的方法
export const savePath = ({ commit }, payload) => {
  commit('savePath', payload)
}

// 触发保存普通搜索内容的方法
export const saveNormalSearchContent = ({ commit }, payload) => {
  commit('saveNormalSearchContent', payload)
}

// 触发保存高级搜索内容的方法
export const saveAdvancedSearchContent = ({ commit }, payload) => {
  commit('saveAdvancedSearchContent', payload)
}

// 触发保存PDF的URL的方法
export const savepdfUrl = ({ commit }, payload) => {
  commit('savepdfUrl', payload)
}

// 触发保存MarkDown的ArticleId的方法
export const saveArticleId = ({ commit }, payload) => {
  commit('saveArticleId', payload)
}

// 触发保存MarkDown的NoteId的方法
export const saveNoteId = ({ commit }, payload) => {
  commit('saveNoteId', payload)
}

// 触发保存token的方法
export const savetoken = ({ commit }, payload) => {
  commit('savetoken', payload)
}

// 触发保存用户名的方法
export const saveUsername = ({ commit }, payload) => {
  commit('saveUsername', payload)
}

// 触发保存昵称的方法
export const saveNickname = ({ commit }, payload) => {
  commit('saveNickname', payload)
}

// 触发保存用户类别的方法
export const saveAuthority = ({ commit }, payload) => {
  commit('saveAuthority', payload)
}

// 触发当前对pdf文献的操作的方法
export const saveOperation = ({ commit }, payload) => {
  commit('saveOperation', payload)
}
