<template>
    <el-card shadow="hover" class="search">
        <div class="search_group">
            <el-row :gutter="20" class="search_item">
                <el-col :span="5">
                  <el-select placeholder="请选择筛选目标" v-model="queryInfo.label">
                    <el-option
                      v-for="item in TargetOptions"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value">
                    </el-option>
                  </el-select>
                </el-col>
                <el-col :span="5">
                  <el-select
                    v-model="queryInfo.label_content"
                    multiple
                    filterable
                    remote
                    reserve-keyword
                    placeholder="请输入筛选条件"
                    :remote-method="remoteMethod"
                    :loading="loading">
                    <el-option
                      v-for="item in SpecificOptions"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value">
                    </el-option>
                  </el-select>
                </el-col>
                <el-col :span="14">
                  <el-input @keyup.enter.native="Search()" v-model="queryInfo.content" placeholder="Search publications, articles, keywords, etc">
                      <el-button slot="append" icon="el-icon-search" @click="TrueSearch()"></el-button>
                  </el-input>
                </el-col>
            </el-row>
        </div>
        <el-row class="meta_result_group">
            <el-col class="guide_line_plus">{{literatures.total}}{{literatures.total > 1 ? Results : Result}}</el-col>
            <el-col class="guide_line_mini">Sorted by {{queryInfo.orderBy}}</el-col>
        </el-row>
        <el-row class="main_frame_work">
            <el-col class="refine_area">
                <h2>Refine by:</h2>
                <div>
                    <p class="refine_item">Years</p>
                    <el-checkbox class="all_check_item" :indeterminate="years.yearIsIndeterminate" v-show="years.done" v-model="years.yearCheckAll" @change="yearHandleCheckAllChange">全选</el-checkbox>
                    <el-checkbox-group class="check_group" v-model="years.checkedYears" @change="yearHandleCheckedChange">
                      <div>
                        <template v-for="(item, index) in years.yearCnts">
                          <el-checkbox v-show="!years.yearShowMore" class="check_item" :label="item.year" v-if="index < 4" :key="index">{{item.year}}({{item.cnt}})</el-checkbox>
                        </template>
                      </div>
                      <div>
                        <template v-for="(item, index) in years.yearCnts">
                          <el-checkbox v-show="years.yearShowMore" class="check_item" :label="item.year" :key="index">{{item.year}}({{item.cnt}})</el-checkbox>
                        </template>
                      </div>
                      <div v-if="years.yearCnts.length > 4">
                        <div class="more_check_item" v-show="!years.yearShowMore" @click="ShowMoreYear">更多>></div>
                        <div class="more_check_item" v-show="years.yearShowMore" @click="ShowMoreYear">^收回</div>
                      </div>
                    </el-checkbox-group>
                    <p class="refine_item">Sorted by</p>
                    <div>
                      <el-radio-group class="check_group" v-model="Sorts.sortedByCode" @change="ChangeSortedBy">
                        <el-radio class="check_item" :label="1">时间</el-radio>
                        <el-radio class="check_item" :label="2">文章id</el-radio>
                      </el-radio-group>
                      <el-radio-group class="check_group" v-model="Sorts.orderedByCode" @change="ChangeOrderedBy">
                        <el-radio class="check_item" :label="1">降序</el-radio>
                        <el-radio class="check_item" :label="2">升序</el-radio>
                      </el-radio-group>
                    </div>
                </div>
            </el-col>
            <el-col class="result_area">
                <div class="text_item" v-for="item in literatures.literatureList" :key="item.id">
                    <el-card
                      class="box-card"
                      v-if="years.checkedYears.indexOf(item.year) !== -1"
                      :style="PDF_BG">
                      <el-row class="text_row">
                        <el-col :span="16">
                          <div>
                            <i class="el-icon-collection"></i>
                            <span class="title" @click="ToPDF(item.url)">{{item.title}}</span>
                            <br>
                            <i class="el-icon-time"></i>
                            <span class="year">{{item.date}}</span>
                            <br>
                            <i class="el-icon-reading"></i>
                            <span class="magazine">{{item.magazine}}</span>
                            <span class="tag_group" v-for="(kitem, index) in item.area" :key="index">
                              <el-tag class="tag" size="mini" type="success">{{kitem}}</el-tag>
                            </span>
                          </div>
                        </el-col>
                        <el-col :span="2">
                          <el-button class="button" type="success" round size="mini" @click="EditRef(item.article_id)">添加引用</el-button>
                          <br>
                          <el-button class="button" type="danger" round size="mini" @click="DeleteArticle(item.article_id)">删除文章</el-button>
                        </el-col>
                        <el-col :span="2">
                          <el-button class="button" type="primary" round size="mini" @click="UpdateArticle(item.article_id, item.url)">更新文章</el-button>
                          <br>
                          <el-button class="button" type="warning" round size="mini" @click="ToNote(item.article_id)">查看笔记</el-button>
                        </el-col>
                        <el-col :span="4">
                        </el-col>
                      </el-row>
                    </el-card>
                </div>
                <div class="block">
                  <el-pagination
                    @size-change="handleSizeChange"
                    @current-change="handleCurrentChange"
                    :current-page="queryInfo.pageNum"
                    :page-sizes="[5, 9, 13, 15]"
                    :page-size="queryInfo.pageSize"
                    layout="total, sizes, prev, pager, next, jumper"
                    :total="literatures.total">
                  </el-pagination>
                </div>
            </el-col>
        </el-row>
    </el-card>
</template>

<script>
export default {
  name: 'AdvancedSearchResult',
  data () {
    return {
      queryInfo: {
        content: '',
        label: '',
        label_content: [],
        pageSize: 13,
        pageNum: 1,
        orderBy: 'date desc'
      },
      literatures: {
        literatureList: [],
        total: 0
      },
      Results: ' Results',
      Result: ' Result',
      Sorts: {
        sortedByCode: 1,
        sortedBy: 'date',
        orderedByCode: 1,
        orderedBy: 'desc'
      },
      years: {
        yearCnts: [],
        checkedYears: [],
        yearShowMore: false,
        yearCheckAll: true,
        yearOption: [],
        yearIsIndeterminate: false,
        done: false
      },
      TmpAreaData: [],
      TargetOptions: [{ label: '请输入筛选目标', value: '' }, { label: 'area', value: 'area' }],
      SpecificOptions: [],
      // options 是用来匹配的选项
      list: [],
      // list 以键值对的形式来存选项
      loading: false,
      states: [],
      // state 感觉是本地查询用的
      PDF_BG: {
        backgroundImage: 'url(' + require('@/assets/PDF_BG.png') + ')'
      }
    }
  },
  created() {
    window.myData = this
    this.queryInfo.content = this.$store.state.Advanced.content
    this.queryInfo.label = this.$store.state.Advanced.label
    this.queryInfo.label_content = this.$store.state.Advanced.label_content
    // this.queryInfo = this.$store.state.Advanced
    this.GetAllArea()
    this.TrueSearch()
  },
  methods: {
    ToAdvanced() {
      this.$router.push('/AdvancedSearch')
    },
    TrueSearch() {
      this.$store.dispatch('saveAdvancedSearchContent', this.queryInfo)
      this.queryInfo.orderBy = this.Sorts.sortedBy + ' ' + this.Sorts.orderedBy
      this.$api.search.searchSubject(this.queryInfo).then(res => {
        if (res.status !== 0) {
          return this.$message.error('搜索失败')
        }
        this.$message.success('搜索成功')
        this.literatures.literatureList = res.data.items
        this.literatures.total = res.data.total
        this.GetYears()
      })
    },
    GetAllArea() {
      this.$api.area.GetAllArea().then(res => {
        this.TmpAreaData = res
        this.ToAreaState()
      })
    },
    ToAreaState() {
      this.states.splice(0, this.states.length)
      for (let i = 0; i < this.TmpAreaData.length; i++) {
        for (let j = 0; j < this.TmpAreaData[i].subAreas.length; j++) {
          for (let k = 0; k < this.TmpAreaData[i].subAreas[j].subAreas.length; k++) {
            let name = this.TmpAreaData[i].subAreas[j].subAreas[k].name
            this.states.push(name)
          }
        }
      }
      this.list = this.states.map(item => {
        return { value: `${item}`, label: `${item}` }
      })
    },
    ChangeSortedBy() {
      if (this.Sorts.sortedByCode === 1) {
        this.Sorts.sortedBy = 'date'
      } else if (this.Sorts.sortedByCode === 2) {
        this.Sorts.sortedBy = 'article_id'
      }
      this.TrueSearch()
    },
    ChangeOrderedBy() {
      if (this.Sorts.orderedByCode === 1) {
        this.Sorts.orderedBy = 'desc'
      } else if (this.Sorts.orderedByCode === 2) {
        this.Sorts.orderedBy = 'asc'
      }
      this.TrueSearch()
    },
    ToPDF(url) {
      this.$store.dispatch('savepdfUrl', url)
      this.$router.push('/PDFView')
    },
    ToNote(ArticleId) {
      this.$store.dispatch('saveArticleId', ArticleId)
      this.$router.push('/NoteList')
    },
    GetYears() {
      this.years.yearCnts.length = 0
      this.years.yearOption.length = 0
      for (let i = 0; i < this.literatures.literatureList.length; i++) {
        const literature = this.literatures.literatureList[i]
        const date = new Date(literature.date)
        const year = date.getFullYear()
        this.literatures.literatureList[i].year = year
        let flag = 0
        for (let j = 0; j < this.years.yearCnts.length; j++) {
          if (this.years.yearCnts[j].year === year) {
            this.years.yearCnts[j].cnt++
            flag = 1
            break
          }
        }
        if (flag === 0) {
          this.years.yearCnts.push({ year: year, cnt: 1 })
          this.years.yearOption.push(year)
        }
      }
      this.years.done = true
      this.years.checkedYears = this.years.yearOption
    },
    ShowMoreYear() {
      this.years.yearShowMore = !this.years.yearShowMore
    },
    yearHandleCheckAllChange(val) {
      this.years.checkedYears = val ? this.years.yearOption : []
      this.years.yearIsIndeterminate = false
    },
    yearHandleCheckedChange(val) {
      this.years.checkedYears = val
      const checkedCount = val.length
      this.years.yearCheckAll = checkedCount === this.years.yearOption.length
      this.years.yearIsIndeterminate = checkedCount > 0 && checkedCount < this.years.yearOption.length
    },
    // 监听 pagesize 改变事件 每页显示的个数
    handleSizeChange(newSize) {
      this.queryInfo.pageSize = newSize
      this.TrueSearch()
    },
    // 监听 页码值 改变的事件 当前页面值
    handleCurrentChange(newPage) {
      this.queryInfo.pageNum = newPage
      this.TrueSearch()
    },
    remoteMethod(query) {
      if (query !== '') {
        this.loading = true
        setTimeout(() => {
          this.loading = false
          this.SpecificOptions = this.list.filter(item => {
            return item.label.toLowerCase()
              .indexOf(query.toLowerCase()) > -1
          })
        }, 200)
      } else {
        this.SpecificOptions = []
      }
    },
    DeleteArticle(ArticleId) {
      this.$api.pdf.DeleteArticle(ArticleId).then(res => {
        if (res.status !== 0) {
          return this.$message.error('删除失败')
        }
        this.$message.success('删除成功')
        this.TrueSearch()
      })
    },
    UpdateArticle(ArticleId, url) {
      this.$store.dispatch('saveArticleId', ArticleId)
      this.$store.dispatch('savepdfUrl', url)
      this.$store.dispatch('saveArticleOperation', 'Update')
      this.$router.push('PDFUpdate')
    },
    EditRef(ArticleId) {
      this.$store.dispatch('saveArticleId', ArticleId)
      this.$router.push('EditRef')
    }
  }
}
</script>

<style lang="less" scoped>
.search {
  .search_content {
    width: 40%;
    margin-left: 30%;
    .guide_line {
    font-size: 14px;
    margin: 10px;
    }
  }
  .search_group {
    width: 60%;
    margin-left: 20%;
    margin-top: 10px;
  }
  .meta_result_group {
    left: 30px;
    .guide_line_plus {
      width: 20%;
      font-size: 24px;
      font-weight: 700;
    }
    .guide_line_mini {
      width: 80%;
      padding-left: 1100px;
      padding-top: 15px;
      font-size: 14px;
    }
  }
}
.main_frame_work {
  margin-top: 20px;
  margin-left: 30px;
  margin-right: 30px;
  .refine_area {
    margin-top: 20px;
    width: 16%;
    .refine_item {
      margin-top: 18px;
      font-size: 16px;
      font-weight: 700;
    }
    .all_check_item {
      margin-top: 6px;
    }
    .check_group {
      margin-top: 4px;
      .check_item {
        margin-top: 6px;
      }
      .more_check_item {
        margin-top: 6px;
        font-size: 14px;
      }
    }
  }
  .result_area {
    width: 82%;
    margin-left: 2%;
    .text_item {
      .box-card {
        margin-bottom: 5px;
        .text_row {
          .title {
            font-family: 'Times New Roman', Times, serif;
            font-size: 24px;
            font-weight: 700;
            margin-top: 5px;
          }
          .el-icon-collection {
            font-size: 170%;
            color: #943b00;
            margin-right: 5px;
          }
          .year {
            font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            font-size: 14px;
            margin-top: 5px;
          }
          .el-icon-time {
            font-size: 120%;
            margin-right: 4px;
            color: rgb(13, 77, 0);
          }
          .magazine {
            font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            font-size: 15px;
            margin-top: 10px;
          }
          .tag_group {
            font-size: 15px;
            margin-top: 10px;
            .tag {
              font-size: 15px;
              margin-left: 5px;
            }
          }
          .el-icon-reading {
            font-size: 120%;
            margin-right: 4px;
            color: rgb(0, 24, 77);
          }
        }
        .button {
           margin-top: 10px;
        }
      }
    }
  }
}
</style>
