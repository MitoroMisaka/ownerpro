<template>
    <div>
      <el-row class="home" :gutter="20">
          <el-col :span="8">
              <el-card shadow="hover" style="height: 372px;">
                <div class="user">
                  <img :src="userInfo.avatar" />
                  <div class="userinfo">
                    <p class="name">{{ userInfo.name }}</p>
                    <p class="subinfo">用户名：{{ userInfo.username }}</p>
                    <p class="subinfo">账号类型：{{ userInfo.type }}</p>
                  </div>
                </div>
                <div class="other_info">
                  <div class="row">
                    <span class="title">拥有权限：</span>
                    <el-tag class="tag" v-if="userInfo.type === '管理员' || userInfo.insert === 1" type="success">增加权限</el-tag>
                    <el-tag class="tag" v-if="userInfo.type === '管理员' || userInfo.delete === 1" type="danger">删除权限</el-tag>
                    <el-tag class="tag" v-if="userInfo.type === '管理员' || userInfo.update === 1">修改权限</el-tag>
                    <el-tag class="tag" v-if="userInfo.type === '管理员' || userInfo.select === 1" type="warning">查询权限</el-tag>
                  </div>
                  <div class="row">
                    <span class="title" v-show="!IsChangePassword">用户操作：</span>
                    <el-button class="button" v-show="!IsChangePassword" type="primary" plain round @click="ChangePassword">修改密码</el-button>
                    <el-input class="input" v-show="IsChangePassword" type="password" v-model="Newpsd" placeholder="请输入新密码"></el-input>
                    <el-button class="button" v-show="IsChangePassword" type="primary" plain round @click="TrueChangePassword">确认修改</el-button>
                    <el-button class="button" v-show="IsChangePassword" type="danger" plain round @click="CancelChangePassword">取消修改</el-button>
                  </div>
                </div>
              </el-card>
          </el-col>
          <el-col :span="8">
              <el-card>
                <p class="pietitle">研究方向统计：</p>
                  <div class="pie" id="pieType" style="width: 300px; height:300px;"></div>
              </el-card>
          </el-col>
          <el-col :span="8">
              <el-card>
                <p class="pietitle">文献类型统计：</p>
                  <div class="pie" id="pieArea" style="width: 300px; height:300px;"></div>
              </el-card>
          </el-col>
      </el-row>
      <el-card shadow="hover" class="search">
        <div>
            <div class="slogan_vice">
                <span slot="title">Accelerating research discovery to shape a better future</span>
            </div>
            <div class="slogan_main">
                <span slot="title">Today's Reasearch, tomorrow's innovation</span>
            </div>
            <div class="search_content">
                <el-input @keyup.enter.native="Search()" v-model="normalSearchContent" placeholder="Search publications, articles, keywords, etc">
                    <el-button slot="append" icon="el-icon-search" @click="Search()"></el-button>
                </el-input>
            </div>
            <el-row class="guide_line">
              <span class="guide_line_left" @click="ToPDFUpload()">添加文献</span>
              <span class="guide_line_right" @click="ToAdvanced()">按学科搜索</span>
            </el-row>
            <div class="info_group">
                <div class="info_item">
                    <span>100+Journals</span>
                </div>
                <div class="info_item">
                    <span>|</span>
                </div>
                <div class="info_item">
                    <span>20+Reference Works</span>
                </div>
                <div class="info_item">
                    <span>|</span>
                </div>
                <div class="info_item">
                    <span>120+Online Books</span>
                </div>
            </div>
        </div>
    </el-card>
    </div>
</template>

<script>
import * as echarts from 'echarts'
import _ from 'lodash'
export default {
  name: 'home',
  data () {
    return {
      countData: [
        {
          name: '今日支付订单',
          value: 1234,
          icon: 'success',
          color: '#2ec7c9'
        },
        {
          name: '今日收藏订单',
          value: 210,
          icon: 'star-on',
          color: '#ffb980'
        },
        {
          name: '今日未支付订单',
          value: 1234,
          icon: 's-goods',
          color: '#5ab1ef'
        },
        {
          name: '本月支付订单',
          value: 1234,
          icon: 'success',
          color: '#2ec7c9'
        },
        {
          name: '本月收藏订单',
          value: 210,
          icon: 'star-on',
          color: '#ffb980'
        },
        {
          name: '本月未支付订单',
          value: 1234,
          icon: 's-goods',
          color: '#5ab1ef'
        }
      ],
      pieCache: {
        title: {
          text: '',
          subtext: '',
          left: 'center'
        },
        tooltip: { // 提示
          trigger: 'item', // 触发方式
          formatter: '{a} <br/>{b}: {c} ({d}%)' // 提示的格式
        },
        series: [
          {
            name: '访问来源',
            type: 'pie',
            radius: '65%',
            center: ['50%', '50%'],
            selectedMode: 'single',
            data: []
          }
        ]
      },
      emphasis: {
        itemStyle: {
          shadowBlur: 10,
          shadowOffsetX: 0,
          shadowColor: 'rgba(0, 0, 0, 0.5)'
        }
      },
      PieRequest: {
        label: ''
      },
      Newpsd: '',
      IsChangePassword: false,
      userInfo: {
      },
      normalSearchContent: ''
    }
  },
  created() {
    window.myData = this
  },
  mounted() {
    this.GetInfo()
    this.DrawPieType()
    this.DrawPieArea()
  },
  methods: {
    DrawPieType() {
      let myChart = echarts.init(document.getElementById('pieType'))
      this.PieRequest.label = 'type'
      this.$api.search.GetPie(this.PieRequest).then(res => {
        if (res.status !== 0) {
          return this.$message.error('获取饼图数据失败!')
        }
        this.pieCache.series[0].data.splice(0, this.pieCache.series[0].data.length)
        const result = _.merge(this.pieCache.series[0].data, res.data)
        myChart.setOption(this.pieCache)
      })
    },
    DrawPieArea() {
      let myChart = echarts.init(document.getElementById('pieArea'))
      this.PieRequest.label = 'area'
      this.$api.search.GetPie(this.PieRequest).then(res => {
        if (res.status !== 0) {
          return this.$message.error('获取饼图数据失败!')
        }
        this.pieCache.series[0].data.splice(0, this.pieCache.series[0].data.length)
        const result = _.merge(this.pieCache.series[0].data, res.data)
        myChart.setOption(this.pieCache)
      })
    },
    GetInfo() {
      this.$api.user.GetInfo().then(res => {
        if (res.status !== 0) {
          return this.$message.error('获取个人信息失败')
        }
        this.$message.success('获取个人信息成功')
        this.userInfo = res.data
      })
    },
    ChangePassword() {
      this.IsChangePassword = true
    },
    TrueChangePassword() {
      this.$api.user.CheckSamePassword(this.Newpsd).then(res => {
        if (res.status !== 0) {
          return this.$message.error('检查密码失败')
        }
        this.$message.success('检查密码成功')
        console.log(this.Newpsd)
        this.$api.user.ChangePassword(this.Newpsd).then(res => {
          if (res.status !== 0) {
            console.log(this.Newpsd)
            return this.$message.error('修改密码失败')
          }
          this.$message.success('修改密码成功')
        })
      })
    },
    CancelChangePassword() {
      this.IsChangePassword = false
    },
    ToAdvanced() {
      this.$router.push('/AdvancedSearch')
    },
    ToPDFUpload() {
      this.$router.push('/PDFUpload')
    },
    Search() {
      this.$store.dispatch('saveNormalSearchContent', this.normalSearchContent)
      this.$router.push('/NormalSearchResult')
    }
  }
}
</script>

<style lang="less" scoped>
  .user {
    display: flex;
    align-items: center;
    padding-bottom: 20px;
    margin-bottom: 20px;
    border-bottom: 1px solid #ccc;
    img {
      width: 150px;
      height: 150px;
      border-radius: 50%;
      margin-right: 40px;
    }
    .userinfo {
      .name {
        font-size: 36px;
        margin-bottom: 10px;
      }
      .subinfo {
        font-size: 15px;
        color: #666666;
      }
    }
  }
  .other_info {
    .row {
      margin-top: 20px;
      .title {
        font-size: 15px;
        color: #666666;
        margin-right: 10px;
      }
      .tag {
        font-size: 15px;
        margin-left: 10px;
      }
      .input {
        margin-top: 10px;
        width: 200px;
      }
      .button {
        margin-top: 10px;
        margin-left: 20px;
      }
    }
  }
  .pietitle {
    font-size: 20px;
    font-weight: 700;
    margin-left: 190px;
  }
  .pie {
    height: 335px;
    margin-left: 100px;
  }
  .search {
    margin-top: 10px;
    background: url(../../../assets/search_background.jpg) top left / 100% 105% no-repeat;
    .slogan_vice {
      font-size: 40px;
      color: #fff;
      text-align: center;
      margin-top: 70px;
    }
    .slogan_main {
      font-size: 60px;
      color: #fff;
      text-align: center;
      margin-top: 20px;
    }
    .search_content {
      width: 40%;
      margin-left: 30%;
      margin-top: 60px;
    }
    .guide_line {
      font-size: 16px;
      margin-top: 10px;
      color: #fff;
      .guide_line_left {
        margin-left: 30%;
      }
      .guide_line_right {
        margin-left: 31%;
      }
    }
    .info_group {
      display: flex;
      justify-content: space-around;
      margin-top: 70px;
      .info_item {
        color: #fff;
        font-size: 24px;
      }
    }
  }
</style>
