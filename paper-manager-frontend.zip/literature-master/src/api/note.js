/**
 * user模块接口列表
 */

import base from './base' // 导入接口域名列表
import axios from '@/utils/http' // 导入http中创建的axios实例
import qs from 'qs' // 根据需求是否导入qs模块

const note = {
  GetAllNote (params) {
    return axios.get(`${base.backdev}/article/get_note`, {
      params: params
    })
  },
  GetNoteById (params) {
    return axios.get(`${base.backdev}/article/get_note_by_id`, {
      params: params
    })
  },
  DeleteNote (NoteId) {
    let params = { note_id: NoteId }
    return axios.post(`${base.backdev}/article/delete_note`, qs.stringify(params))
  }
  // 其他接口…………
}

export default note
