<template>
  <div class="users">
    <Breadcrumb name1="用户管理" name2="用户列表" />
    <!-- 卡片视图区域 -->
    <el-card class="box-card">
      <el-row :gutter="20">
        <el-col :span="10">
          <!-- 搜索与添加区域 -->
          <el-input @keyup.enter.native="GetUser" placeholder="请输入内容" clearable v-model="queryInfo.content" @clear="GetUser">
            <el-button slot="append" icon="el-icon-search" @click="GetUser"></el-button>
          </el-input>
        </el-col>
      </el-row>
      <!-- 用户列表 -->
      <el-table :data="userData.userList" stripe style="width: 100%" border>
        <el-table-column type="index" label="#"></el-table-column>
        <el-table-column prop="username" label="用户名"></el-table-column>
        <!-- <el-table-column label="状态">
          <template v-slot="scope">
            <el-switch v-model="scope.row.mg_state" active-color="#13ce66" inactive-color="#ff4949" @change="userStatuChanged(scope.row)"> </el-switch>
          </template>
        </el-table-column> -->
        <el-table-column label="管理用户权限" width="300px">
          <template v-slot="scope">
            <!-- 增加权限按钮 -->
            <el-button type="success" :plain="!Boolean(scope.row.insert_set)" icon="el-icon-plus" size="mini" @click="ChangeInsert(scope.$index)"></el-button>
            <!-- 删除权限按钮 -->
            <el-button type="danger" :plain="!Boolean(scope.row.delete_set)" icon="el-icon-delete" size="mini" @click="ChangeDelete(scope.$index)"></el-button>
            <!-- 修改权限按钮 -->
            <el-button type="primary" :plain="!Boolean(scope.row.update_set)" icon="el-icon-edit" size="mini" @click="ChangeUpdate(scope.$index)"></el-button>
            <!-- 查询权限按钮 -->
            <el-button type="warning" :plain="!Boolean(scope.row.select_set)" icon="el-icon-search" size="mini" @click="ChangeSelect(scope.$index)"></el-button>
            <!-- 分配角色按钮 -->
            <!-- <el-tooltip effect="dark" content="分配角色" placement="top" :enterable="false">
              <el-button type="warning" icon="el-icon-setting" size="mini" @click="setRoles(scope.row)"></el-button>
            </el-tooltip> -->
          </template>
        </el-table-column>
        <el-table-column label="删除用户" width="800px">
          <template v-slot="scope">
            <!-- 增加权限按钮 -->
            <el-button type="danger" icon="el-icon-delete" size="mini" @click="DeleteUser(scope.$index)"></el-button>
          </template>
        </el-table-column>
      </el-table>

      <!-- 分页 -->
      <el-pagination
        @current-change="handleCurrentChange"
        :current-page="queryInfo.pageNum"
        @size-change="handleSizeChange"
        :page-size="queryInfo.pageSize"
        :page-sizes="[5, 9, 13, 15]"
        layout="total, sizes, prev, pager, next, jumper"
        :total="userData.total"
      >
      </el-pagination>
    </el-card>
    <!-- 添加用户对话框 -->
    <el-dialog title="添加用户" :visible.sync="addDialogVisible" width="30%" @close="addDislogClosed">
      <!-- 内容主题区域 -->
      <el-form label-width="90px" ref="addFormRef" :model="addForm" :rules="addFormRules">
        <el-form-item label="姓名" prop="name">
          <el-input v-model="addForm.name"></el-input>
        </el-form-item>
        <el-form-item label="年龄" prop="age">
          <el-input v-model.number="addForm.age"></el-input>
        </el-form-item>
        <el-form-item label="兴趣爱好" prop="hobby">
          <el-input v-model="addForm.hobby"></el-input>
        </el-form-item>
        <el-form-item label="联系方式" prop="contact">
          <el-input v-model="addForm.contact"></el-input>
        </el-form-item>
        <el-form-item label="自我介绍" prop="introduction">
          <el-input v-model="addForm.introduction"></el-input>
        </el-form-item>
      </el-form>
      <!-- 底部按钮区域 -->
      <span slot="footer" class="dialog-footer">
        <el-button @click="addDialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="addUser">确 定</el-button>
      </span>
    </el-dialog>
    <!-- 修改用户信息对话框 -->
    <el-dialog title="修改用户" :visible.sync="editDialogVisble" width="50%" @close="aditClosed">
      <el-form :model="editForm" :rules="editFormRules" ref="editFormRef" label-width="70px">
        <el-form-item label="姓名" prop="name">
          <el-input v-model="editForm.name"></el-input>
        </el-form-item>
        <el-form-item label="年龄" prop="age">
          <el-input v-model.number="editForm.age"></el-input>
        </el-form-item>
        <el-form-item label="兴趣爱好" prop="hobby">
          <el-input v-model="editForm.hobby"></el-input>
        </el-form-item>
        <el-form-item label="联系方式" prop="contact">
          <el-input v-model="editForm.contact"></el-input>
        </el-form-item>
        <el-form-item label="自我介绍" prop="introduction">
          <el-input v-model="editForm.introduction"></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="editDialogVisble = false">取 消</el-button>
        <el-button type="primary" @click="editUserInfo">确 定</el-button>
      </span>
    </el-dialog>
    <!-- 分配角色 -->
    <el-dialog title="分配角色" :visible.sync="setRolesDialogVisible" @close="setRolesDialogClosed" width="50%">
      <div>
        <p>当前的用户 : {{ userInfo.username }}</p>
        <p>当前的角色 : {{ userInfo.role_name }}</p>
        <p>
          分配新角色:
          <el-select v-model="selectRoleId" placeholder="请选择">
            <el-option v-for="item in rolesList" :key="item.id" :label="item.roleName" :value="item.id"> </el-option>
          </el-select>
        </p>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="setRolesDialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="saveRolesInfo">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import { userAddFormRulesMixin } from '@/common/mixin.js'
import Breadcrumb from 'components/content/breadcrumb/Breadcrumb'
export default {
  name: 'Users',
  mixins: [userAddFormRulesMixin],
  data() {
    return {
      queryInfo: {
        content: '',
        pageNum: 1,
        pageSize: 5,
        orderBy: 'id asc'
      },
      TmpAuthority: {
        id: 0,
        select_set: 0,
        update_set: 0,
        delete_set: 0,
        insert_set: 0
      },
      // 存放用户的数据和数量
      userData: {
        userList: [],
        total: 0
      },
      // 控制用户对话框的显示和隐藏
      addDialogVisible: false,
      // 添加用户数据的对象
      addForm: {
        name: '',
        age: 18,
        hobby: '',
        contact: '',
        introduction: ''
      },
      // 修改用户消息对话框显示和隐藏
      editDialogVisble: false,
      // 控制分配角色对话框的显示和隐藏
      setRolesDialogVisible: false,
      // 需要被分配角色的用户信息
      userInfo: {},
      // 分配角色列表
      rolesList: [],
      // 保存已经选中的角色id值
      selectRoleId: '',
      // 查询用户的对象
      editForm: {
        id: '',
        name: '',
        age: 18,
        hobby: '',
        contact: '',
        introduction: ''
      }
    }
  },
  components: {
    Breadcrumb
  },
  created() {
    window.myData = this
    this.GetUser()
  },
  methods: {
    GetUser() {
      this.$api.user.GetUserByName(this.queryInfo).then(res => {
        if (res.status !== 0) {
          this.$message.error('获取用户列表失败!')
        } else {
          this.$message.success('获取用户列表成功!')
          this.userData.userList = res.data.items
          this.userData.total = res.data.total
        }
      })
    },
    // 修改用户Select权限
    ChangeInsert(index) {
      this.TmpAuthority.id = this.userData.userList[index].id
      this.TmpAuthority.insert_set = this.userData.userList[index].insert_set
      this.TmpAuthority.delete_set = this.userData.userList[index].delete_set
      this.TmpAuthority.update_set = this.userData.userList[index].update_set
      this.TmpAuthority.select_set = this.userData.userList[index].select_set
      this.TmpAuthority.insert_set = this.TmpAuthority.insert_set === 1 ? 0 : 1
      this.$api.user.ChangeAuthority(this.TmpAuthority).then(res => {
        if (res.status !== 0) {
          return this.$message.error('修改权限失败')
        }
        this.$message.success('修改权限成功')
        this.userData.userList[index].insert_set = this.TmpAuthority.insert_set
      })
    },
    // 修改用户Delete权限
    ChangeDelete(index) {
      this.TmpAuthority.id = this.userData.userList[index].id
      this.TmpAuthority.insert_set = this.userData.userList[index].insert_set
      this.TmpAuthority.delete_set = this.userData.userList[index].delete_set
      this.TmpAuthority.update_set = this.userData.userList[index].update_set
      this.TmpAuthority.select_set = this.userData.userList[index].select_set
      this.TmpAuthority.delete_set = this.TmpAuthority.delete_set === 1 ? 0 : 1
      this.$api.user.ChangeAuthority(this.TmpAuthority).then(res => {
        if (res.status !== 0) {
          return this.$message.error('修改权限失败')
        }
        this.$message.success('修改权限成功')
        this.userData.userList[index].delete_set = this.TmpAuthority.delete_set
      })
    },
    // 修改用户Update权限
    ChangeUpdate(index) {
      this.TmpAuthority.id = this.userData.userList[index].id
      this.TmpAuthority.insert_set = this.userData.userList[index].insert_set
      this.TmpAuthority.delete_set = this.userData.userList[index].delete_set
      this.TmpAuthority.update_set = this.userData.userList[index].update_set
      this.TmpAuthority.select_set = this.userData.userList[index].select_set
      this.TmpAuthority.update_set = this.TmpAuthority.update_set === 1 ? 0 : 1
      this.$api.user.ChangeAuthority(this.TmpAuthority).then(res => {
        if (res.status !== 0) {
          return this.$message.error('修改权限失败')
        }
        this.$message.success('修改权限成功')
        this.userData.userList[index].update_set = this.TmpAuthority.update_set
      })
    },
    // 修改用户Select权限
    ChangeSelect(index) {
      this.TmpAuthority.id = this.userData.userList[index].id
      this.TmpAuthority.insert_set = this.userData.userList[index].insert_set
      this.TmpAuthority.delete_set = this.userData.userList[index].delete_set
      this.TmpAuthority.update_set = this.userData.userList[index].update_set
      this.TmpAuthority.select_set = this.userData.userList[index].select_set
      this.TmpAuthority.select_set = this.TmpAuthority.select_set === 1 ? 0 : 1
      this.$api.user.ChangeAuthority(this.TmpAuthority).then(res => {
        if (res.status !== 0) {
          return this.$message.error('修改权限失败')
        }
        this.$message.success('修改权限成功')
        this.userData.userList[index].select_set = this.TmpAuthority.select_set
      })
    },
    // 监听 pagesize 改变事件 每页显示的个数
    handleSizeChange(newSize) {
      this.queryInfo.pageSize = newSize
      this.GetUser()
    },
    // 监听 页码值 改变的事件 当前页面值
    handleCurrentChange(newPage) {
      this.queryInfo.pageNum = newPage
      this.GetUser()
    },
    // 监听Switch状态的改变
    async userStatuChanged(userInfo) {
      // console.log(userInfo)
      const { data: res } = await this.$http.put(`users/${userInfo.id}/state/${userInfo.mg_state}`)
      if (res.meta.status !== 200) {
        userInfo.mg_state = !userInfo.mg_state
        return this.$message.error('更新用户状态失败!')
      }
      return this.$message.success('更新用户状态成功!')
    },
    // 监听添加用户的对话框关闭事件
    addDislogClosed() {
      this.$refs.addFormRef.resetFields()
    },
    // 点击按钮,添加新用户
    addUser() {
      this.$refs.addFormRef.validate(async valid => {
        console.log(valid)
        if (!valid) return
        // 可以发起添加用户请求
        const param = new URLSearchParams()
        param.append('name', this.addForm.name)
        param.append('age', this.addForm.age)
        param.append('hobby', this.addForm.hobby)
        param.append('contact', this.addForm.contact)
        param.append('introduction', this.addForm.introduction)
        const { data: res } = await this.$http.post('team/add', param)
        if (res.status !== 0) {
          return this.$message.error('用户添加失败了~')
        }
        // 隐藏添加用户的对话框
        this.addDialogVisible = false
        // 添加成后重新获取用户数据,不需要用户手动刷新
        this.GetAllUser()
        return this.$message.success('用户添加成功了~')
      })
    },
    // 展示编辑用于的对话框
    async showEditDialog(id) {
      const { data: res } = await this.$http.get('team/getinfobyid/', {
        params: {
          id
        }
      })
      if (res.status !== 0) {
        return this.$message.error('查询用户数据失败~')
      }
      this.editForm = res.data
      console.log(res)
      this.editDialogVisble = true
      return this.$message.success('查询用户数据成功~')
    },
    // 监听修改用户对话框的关闭事件
    aditClosed() {
      this.$refs.editFormRef.resetFields()
    },
    editUserInfo() {
      this.$refs.editFormRef.validate(async valid => {
        console.log(valid)
        if (!valid) return
        // 发起修改用户信息的数据请求
        const param = new URLSearchParams()
        param.append('id', this.editForm.id)
        param.append('name', this.editForm.name)
        param.append('age', this.editForm.age)
        param.append('hobby', this.editForm.hobby)
        param.append('contact', this.editForm.contact)
        param.append('introduction', this.editForm.introduction)
        const { data: res } = await this.$http.post('team/update_allinfo/', param)
        if (res.status !== 0) {
          this.$message.error('更新用户信息失败!')
        }
        this.editDialogVisble = false
        this.GetAllUser()
        this.$message.success('更新用户信息成功!')
      })
    },
    // 根据id删除对应的用户信息
    async removeUserById(id) {
      // 询问用户是否删除用户
      const confirmRusult = await this.$confirm('此操作将永久删除该文件, 是否继续?', '永久删除该用户', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).catch(err => err)
      console.log(confirmRusult)
      // 用户点击了删除,则返回字符串 confirm
      // 用户取消了删除,则返回字符串 cancel
      if (confirmRusult !== 'confirm') {
        return this.$message.info('已经取消了删除')
      }
      const param = new URLSearchParams()
      param.append('id', id)
      const { data: res } = await this.$http.post('team/delete/', param)
      if (res.status !== 0) {
        return this.$message.error('该用户删除失败')
      }
      this.$message.success('该用户已经删除')
      this.GetAllUser()
    },
    // 展示分配角色的对话框
    async setRoles(userInfo) {
      this.userInfo = userInfo
      // 再展示对话框之前获取所有的角色列表
      const { data: res } = await this.$http.get('roles')
      if (res.meta.status !== 200) {
        return this.$message.error('获取角色列表失败!')
      }
      this.rolesList = res.data
      this.setRolesDialogVisible = true
    },
    // 点击按钮,分配角色
    async saveRolesInfo() {
      if (!this.selectRoleId) {
        return this.$message.error('请选择要分配的角色!')
      }
      const { data: res } = await this.$http.put(`users/${this.userInfo.id}/role`, {
        rid: this.selectRoleId
      })
      if (res.meta.status !== 200) {
        return this.$message.error('更新角色失败!')
      }
      this.$message.success('更新角色成功!')
      this.GetAllUser()
      this.setRolesDialogVisible = false
    },
    // 分配角色对话框关闭
    setRolesDialogClosed() {
      this.selectRoleId = ''
      this.userInfo = ''
    },
    DeleteUser(index) {
      this.$api.user.DeleteUser(this.userData.userList[index].id).then(res => {
        if (res.status !== 0) {
          return this.$message.error('删除用户失败!')
        }
        this.$message.success('删除用户成功!')
        this.GetUser()
      })
    }
  }
}
</script>

<style lang="less" scoped>
.el-table {
  margin-top: 15px;
}
</style>
