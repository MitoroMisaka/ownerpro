<template>
  <div>
    <mavon-editor :ishljs="true" v-model="NoteRequest.content" ref="md" @save="save" @imgAdd="imgAdd" />
  </div>
</template>
<script>
import { mavonEditor } from 'mavon-editor'
import 'mavon-editor/dist/css/index.css'
export default {
  name: 'Update',
  data () {
    return {
      NoteRequest: {
        article_id: 0,
        note_id: 0,
        content: ''
      },
      GetNoteRequest: {
        note_id: 0
      }
    }
  },
  created() {
    window.myData = this
    this.NoteRequest.article_id = this.$store.state.ArticleId
    this.NoteRequest.note_id = this.$store.state.NoteId
    this.GetNoteRequest.note_id = this.$store.state.NoteId
    this.GetNote()
  },
  methods: {
    // 保存md到后台
    save() {
      this.$api.markdown.UpdateNote(this.NoteRequest).then(res => {
        if (res.status !== 0) {
          return this.$message.error('更新失败')
        }
        this.$message.success('更新成功')
        this.dialogFormVisible = false
      })
    },
    // 保存图片到后台
    imgAdd(pos, $file) {
      // 第一步.将图片上传到服务器.
      var formdata = new FormData()
      formdata.append('multipartFile', $file)
      this.$api.markdown.uploadFile(formdata).then(res => {
        var url = res.data // 取出上传成功后的url
        // url = 'http://localhost:8080/api/' + url.substring(22)
        if (res.status === 0) {
          //  将后端返回的url放在md中图片的指定位置
          console.log(url)
          this.$refs.md.$img2Url(pos, url)
        } else {
          this.$message('图片上传失败')
        }
      })
    },
    GetNote() {
      this.$api.note.GetNoteById(this.GetNoteRequest).then(res => {
        this.NoteRequest.content = res.content
      })
    }
  },
  components: {
    mavonEditor
  }
}
</script>
