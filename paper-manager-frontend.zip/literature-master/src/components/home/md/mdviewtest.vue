<template>
  <div class="markdown-body">
    <VueMarkdown :source="mdData" v-highlight></VueMarkdown>
  </div>
</template>

<script>
import VueMarkdown from 'vue-markdown'
// 这种方式引入 数据可直接使用
import markdownData from '../../../assets/md/demo.md'
export default {
  components: {
    VueMarkdown
  },
  data() {
    return {
      mdData: markdownData
    }
  }
}
</script>
