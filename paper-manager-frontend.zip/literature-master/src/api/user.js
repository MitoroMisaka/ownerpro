/**
 * user模块接口列表
 */

import base from './base' // 导入接口域名列表
import axios from '@/utils/http' // 导入http中创建的axios实例
import qs from 'qs' // 根据需求是否导入qs模块
import { orderBy } from 'lodash'

const user = {
  // 登录
  Login (params) {
    return axios.post(`${base.backdev}/account/signIn`, qs.stringify(params))
  },
  // 发送邮箱验证信息
  EmailSend (email) {
    let params = { email: email }
    return axios.post(`${base.backdev}/mail/send`, qs.stringify(params))
  },
  Register (params) {
    return axios.post(`${base.backdev}/account/signUp`, qs.stringify(params))
  },
  // 判断密码是否相同
  CheckSamePassword (Newpsd) {
    return axios.get(`${base.backdev}/account/checkPassword`, {
      params: {
        password: Newpsd
      }
    })
  },
  // 修改密码
  ChangePassword (Newpsd) {
    let params = { password: Newpsd }
    return axios.post(`${base.backdev}/account/changePassword`, qs.stringify(params))
  },
  // 登出
  SignOut () {
    return axios.post(`${base.backdev}/account/signOut`)
  },
  GetUserByName(params) {
    return axios.get(`${base.backdev}/search/user`, {
      params: params
    })
  },
  ChangeAuthority(params) {
    return axios.post(`${base.backdev}/account/changeRole`, params)
  },
  DeleteUser(id) {
    let params = { id: id }
    return axios.get(`${base.backdev}/account/deleteUser`, {
      params: params
    })
  },
  GetInfo() {
    return axios.get(`${base.backdev}/account/all`)
  }
}

export default user
