/**
 * api接口的统一出口
 */
// 用户模块接口
import user from '@/api/user'
// 搜索模块接口
import search from '@/api/search'
// MarkDown模块接口
import markdown from '@/api/markdown'
// Note模块接口
import note from '@/api/note'
// PDF模块接口
import pdf from '@/api/pdf'
// comment模块接口
import comment from '@/api/comment'
// area模块接口
import area from '@/api/area'
// 其他模块的接口……

// 导出接口
export default {
  user,
  search,
  markdown,
  note,
  pdf,
  comment,
  area
  // ……
}
