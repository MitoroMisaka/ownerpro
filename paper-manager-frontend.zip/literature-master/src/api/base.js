/**
 * 接口域名的管理
 */
const base = {
  backdev: 'api',
  rawdev: 'http://127.0.0.1:8888/api/private/v1',
  mockdev: 'https://4d6d3430-c5d6-4709-a653-02d1e80ea169.mock.pstmn.io'
}

export default base
