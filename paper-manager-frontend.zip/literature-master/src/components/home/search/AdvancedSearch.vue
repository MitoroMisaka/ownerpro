<template>
    <el-card shadow="hover" class="search">
        <div>
            <div class="slogan_vice">
                <span slot="title">Accelerating research discovery to shape a better future</span>
            </div>
            <div class="slogan_main">
                <span slot="title">Today's Reasearch, tomorrow's innovation</span>
            </div>
            <div class="search_group">
              <el-row :gutter="20" class="search_item">
                <el-col :span="5">
                  <el-select placeholder="请选择筛选目标" v-model="Advanced.label">
                    <el-option
                      v-for="item in TargetOptions"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value">
                    </el-option>
                  </el-select>
                </el-col>
                <el-col :span="5">
                  <el-select
                    v-model="Advanced.label_content"
                    multiple
                    filterable
                    remote
                    :remote-method="remoteMethod"
                    reserve-keyword
                    placeholder="请输入筛选条件"
                    :loading="loading">
                    <el-option
                      v-for="item in SpecificOptions"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value">
                    </el-option>
                  </el-select>
                </el-col>
                <el-col :span="14">
                  <el-input @keyup.enter.native="Search()" v-model="Advanced.content" placeholder="Search publications, articles, keywords, etc">
                      <el-button slot="append" icon="el-icon-search" @click="Search()"></el-button>
                  </el-input>
                </el-col>
              </el-row>
            </div>
            <div class="guide_line">
                <span @click="ToNormal()">按标题搜索</span>
            </div>
            <div class="info_group">
                <div class="info_item">
                    <span>100+Journals</span>
                </div>
                <div class="info_item">
                    <span>|</span>
                </div>
                <div class="info_item">
                    <span>20+Reference Works</span>
                </div>
                <div class="info_item">
                    <span>|</span>
                </div>
                <div class="info_item">
                    <span>120+Online Books</span>
                </div>
            </div>
        </div>
    </el-card>
</template>

<script>
export default {
  name: 'AdvancedSearch',
  data () {
    return {
      Advanced: {
        content: '',
        label: '',
        // label 用来放选中的筛选目标
        label_content: []
        // label_content 用来放选中的具体筛选条件
      },
      TmpAreaData: [],
      TargetOptions: [{ label: '请输入筛选目标', value: '' }, { label: '研究方向', value: 'area' }],
      SpecificOptions: [],
      // options 是用来匹配的选项
      list: [],
      // list 以键值对的形式来存选项
      loading: false,
      states: []
      // state 感觉是本地查询用的
    }
  },
  created() {
    window.myData = this
    this.GetAllArea()
  },
  methods: {
    ToNormal() {
      this.$router.push('/NormalSearch')
    },
    GetAllArea() {
      this.$api.area.GetAllArea().then(res => {
        this.TmpAreaData = res
        this.ToAreaState()
      })
    },
    ToAreaState() {
      this.states.splice(0, this.states.length)
      for (let i = 0; i < this.TmpAreaData.length; i++) {
        for (let j = 0; j < this.TmpAreaData[i].subAreas.length; j++) {
          for (let k = 0; k < this.TmpAreaData[i].subAreas[j].subAreas.length; k++) {
            let name = this.TmpAreaData[i].subAreas[j].subAreas[k].name
            this.states.push(name)
          }
        }
      }
      this.list = this.states.map(item => {
        return { value: `${item}`, label: `${item}` }
      })
    },
    remoteMethod(query) {
      if (query !== '') {
        this.loading = true
        setTimeout(() => {
          this.loading = false
          this.SpecificOptions = this.list.filter(item => {
            return item.label.toLowerCase()
              .indexOf(query.toLowerCase()) > -1
          })
        }, 200)
      } else {
        this.SpecificOptions = []
      }
    },
    Search() {
      this.$store.dispatch('saveAdvancedSearchContent', this.Advanced)
      this.$router.push('/AdvancedSearchResult')
    }
  }
}
</script>

<style lang="less" scoped>
.search {
  background: url(../../../assets/search_background.jpg) top left / 100% 105% no-repeat;
  .slogan_vice {
    font-size: 40px;
    color: #fff;
    text-align: center;
    margin-top: 70px;
  }
  .slogan_main {
    font-size: 60px;
    color: #fff;
    text-align: center;
    margin-top: 20px;
  }
  .search_group {
    width: 60%;
    margin-left: 20%;
    margin-top: 70px;
  }
  .guide_line {
    font-size: 16px;
    margin-top: 10px;
    margin-left: 75%;
    color: #fff;
  }
  .info_group {
    display: flex;
    justify-content: space-around;
    margin-top: 70px;
    .info_item {
      color: #fff;
      font-size: 24px;
    }
  }
}
</style>
