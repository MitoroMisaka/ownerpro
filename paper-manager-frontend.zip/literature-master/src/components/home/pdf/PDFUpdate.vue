<template>
  <div class="frame">
    <!-- 标题 -->
    <div class="title">
      <span>标题：</span>
      <el-input v-model="ArticleRequest.title" style="width: 500px" name="title" placeholder="请输入标题"></el-input>
    </div>
    <!-- 刊会 -->
    <div class="title">
      <span>刊会：</span>
      <el-input v-model="ArticleRequest.magazine" style="width: 500px" name="title" placeholder="请输入刊会"></el-input>
    </div>
    <!-- 刊会时间 -->
    <div class="title">
      <span>刊会时间：</span>
      <el-input v-model="ArticleRequest.date" type="date" style="width: 500px" name="title" placeholder="请输入刊会时间"></el-input>
    </div>
    <!-- 摘要 -->
    <div class="title">
      <span>摘要：</span>
      <el-input v-model="ArticleRequest.abstract_content" type="textarea" style="width: 500px" name="title" placeholder="请输入摘要"></el-input>
    </div>
    <!-- 作者数组动态标签 -->
    <div class="title">
      <span>作者：</span>
      <el-tag
        :key="tag"
        v-for="tag in ArticleRequest.writer"
        closable
        :disable-transitions="false"
        @close="AuthorHandleClose(tag)">
        {{tag}}
      </el-tag>
      <el-input
        class="input-new-tag"
        v-if="AuthorInputVisible"
        v-model="AuthorInputValue"
        ref="AuthorTag"
        size="small"
        @keyup.enter.native="AuthorHandleInputConfirm"
        @blur="AuthorHandleInputConfirm"
      >
      </el-input>
      <el-button v-else class="button-new-tag" size="small" @click="AuthorTagShowInput">+ 添加一个新作者</el-button>
    </div>
    <!-- 文章类型下拉框 -->
    <div class="title">
      <span>文章类型：</span>
      <el-select v-model="ArticleRequest.type" multiple placeholder="请选择">
        <el-option
          v-for="item in TypeOptions"
          :key="item.value"
          :label="item.label"
          :value="item.value">
        </el-option>
      </el-select>
    </div>
    <!-- 文章研究方向下拉框 -->
    <div class="title">
      <span>研究方向：</span>
      <el-tag
        :key="tag"
        v-for="tag in ArticleRequest.area"
        closable
        :disable-transitions="false"
        @close="AreaHandleClose(tag)">
        {{tag}}
      </el-tag>
      <el-cascader
        v-model="AreaValueTmp"
        :options="AreaOptions"
        :props="{ expandTrigger: 'hover' }"
        @change="PushArea">
      </el-cascader>
    </div>
    <!-- 文章关键字数组动态标签 -->
    <div class="title">
      <span>关键字：</span>
      <el-tag
        :key="tag"
        v-for="tag in ArticleRequest.keyword"
        closable
        :disable-transitions="false"
        @close="KeywordHandleClose(tag)">
        {{tag}}
      </el-tag>
      <el-input
        class="input-new-tag"
        v-if="KeywordInputVisible"
        v-model="KeywordInputValue"
        ref="KeywordTag"
        size="small"
        @keyup.enter.native="KeywordHandleInputConfirm"
        @blur="KeywordHandleInputConfirm"
      >
      </el-input>
      <el-button v-else class="button-new-tag" size="small" @click="KeywordTagShowInput">+ 添加一个新关键字</el-button>
    </div>
    <!-- 上传文件 -->
    <div class="title">
      <el-upload
        multiple
        drag
        action=""
        :http-request="UploadPDF"
        :file-list="fileArr"
        :before-upload="beforeUpload"
        :on-change="imgPreview"
        :on-preview="handlefileList"
        :on-remove="handleRemove"
        :on-success="successUpload"
        :on-error="errorUpload"
        :limit="3"
      >
        <i class="el-icon-upload"></i>
        <div class="el-upload__text">将文件拖到此处，或<em>点击上传</em></div>
        <div class="el-upload__tip" slot="tip">
          只能上传.pdf文件，且不超过1MB
        </div>
      </el-upload>
      <!-- 展示pdf -->
      <div style="width:75%;margin:auto">
        <!-- 遍历总页数 渲染每一页-->
        <pdf v-for="page in numPages" :key="page" :src="pdfUrl" :page="page"> </pdf>
      </div>
    </div>
    <!-- 上传按钮 -->
    <div class="title">
      <el-button type="primary" @click="UpdateAll">修改</el-button>
    </div>
  </div>
</template>

<script>
import pdf from 'vue-pdf'
export default {
  components: { pdf },
  data() {
    return {
      numPages: '',
      fileArr: [],
      ArticleId: 0,
      pdfUrl: '', // 展示的pdf文件地址
      AuthorInputVisible: false,
      KeywordInputVisible: false,
      AuthorInputValue: '',
      KeywordInputValue: '',
      TypeOptions: [{
        value: '专著',
        label: '专著'
      }, {
        value: '论文集',
        label: '论文集'
      }, {
        value: '报纸文章',
        label: '报纸文章'
      }, {
        value: '期刊文章',
        label: '期刊文章'
      }, {
        value: '学位论文',
        label: '学位论文'
      }, {
        value: '研究报告',
        label: '研究报告'
      }, {
        value: '标准',
        label: '标准'
      }, {
        value: '专利',
        label: '专利'
      }, {
        value: '专著、论文集中的析出文献',
        label: '专著、论文集中的析出文献'
      }, {
        value: '电子公告',
        label: '电子公告'
      }],
      TmpAreaOptions: [],
      TmpSecAreaItem: {
        label: '',
        value: '',
        children: []
      },
      TmpFirAreaItem: {
        label: '',
        value: '',
        children: []
      },
      AreaOptions: [],
      AreaValueTmp: '',
      ArticleRequest: {
        article_id: 0,
        title: '',
        magazine: '',
        date: '',
        abstract_content: '',
        url: '',
        writer: [],
        type: [],
        area: [],
        keyword: []
        // Reference: ''
      }
    }
  },
  created() {
    window.myData = this
    this.ArticleId = this.$store.state.ArticleId
    this.pdfUrl = this.$store.state.pdfUrl
    this.GetArea()
    this.GetMetaArticle()
  },
  methods: {
    GetArea() {
      this.$api.pdf.GetArea(this.ArticleId).then(res => {
        this.TmpAreaOptions = res
        this.ToAreaOption()
      })
    },
    ToAreaOption() {
      for (let i = 0; i < this.TmpAreaOptions.length; i++) {
        this.TmpFirAreaItem.children.splice(0, this.TmpFirAreaItem.children.length)
        for (let j = 0; j < this.TmpAreaOptions[i].subAreas.length; j++) {
          this.TmpSecAreaItem.children.splice(0, this.TmpSecAreaItem.children.length)
          for (let k = 0; k < this.TmpAreaOptions[i].subAreas[j].subAreas.length; k++) {
            let label = this.TmpAreaOptions[i].subAreas[j].subAreas[k].name
            let value = this.TmpAreaOptions[i].subAreas[j].subAreas[k].name
            this.TmpSecAreaItem.children.push({ label: label, value: value })
          }
          this.TmpSecAreaItem.label = this.TmpAreaOptions[i].subAreas[j].name
          this.TmpSecAreaItem.value = this.TmpAreaOptions[i].subAreas[j].name
          this.TmpFirAreaItem.children.push(JSON.parse(JSON.stringify(this.TmpSecAreaItem)))
        }
        this.TmpFirAreaItem.label = this.TmpAreaOptions[i].name
        this.TmpFirAreaItem.value = this.TmpAreaOptions[i].name
        this.AreaOptions.push(JSON.parse(JSON.stringify(this.TmpFirAreaItem)))
      }
    },
    GetMetaArticle () {
      this.$api.markdown.GetMetaArticle(this.ArticleId).then(res => {
        this.$message.success('获取元数据成功')
        this.ArticleRequest.article_id = this.ArticleId
        this.ArticleRequest.title = res.title
        this.ArticleRequest.magazine = res.magazine
        this.ArticleRequest.date = res.date
        this.ArticleRequest.abstract_content = res.abstract_content
        this.ArticleRequest.url = res.url
        this.ArticleRequest.writer = res.writer
        this.ArticleRequest.type = res.type
        this.ArticleRequest.area = res.area
        this.ArticleRequest.keyword = res.keyword
        this.pdfurl = res.url
      })
    },
    UploadPDF(param) {
      var formdata = new FormData()
      formdata.append('multipartFile', param.file)
      this.$api.pdf.PostPDF(formdata).then(res => {
        if (res.status !== 0) {
          return this.$message.error('上传PDF失败')
        }
        this.$message.success('上传PDF成功')
        this.ArticleRequest.url = res.data
      })
    },
    UpdateAll() {
      this.$api.pdf.UpdateArticle(this.ArticleRequest).then(res => {
        if (res.status !== 0) {
          return this.$message.error('更新文献失败')
        }
        this.$message.success('更新文献成功')
      })
    },
    errorUpload() {
      this.$message({
        message: '上传失败',
        type: 'warning'
      })
    },
    successUpload() {
      this.$message({
        message: '上传成功',
        type: 'success'
      })
    },
    beforeUpload(file) {
      var is20M = file.size / 1024 / 1024 < 20
      if (!is20M) {
        this.$message({
          message: '上传文件大小不能超过 20MB!',
          type: 'warning'
        })
        return false
      }
      // let regex = /(.jpg|.jpeg|.gif|.png|.pdf)$/;
      let regex = /(.pdf)$/
      if (regex.test(file.name.toLowerCase())) {
        console.log('校验通过')
      } else {
        this.$message.warning('只能上传.pdf文件')
        return false
      }
    },
    handlefileList(file) {
      // 点击已上传文件列表的钩子
      this.pdfUrl = this.getPdfUrl(file)
    },
    handleRemove(file) {
      this.pdfUrl = ''
    },
    imgPreview(file) {},
    // 处理文件
    getPdfUrl(file) {
      let url = URL.createObjectURL(file.raw) // 将文件转化成url
      let loadingTask = pdf.createLoadingTask(url)
      loadingTask.promise.then(pdf => {
        this.numPages = pdf.numPages
        // console.log(this.numPages);pdf总页数
      })
      return url
    },
    AuthorHandleClose(tag) {
      this.ArticleRequest.writer.splice(this.ArticleRequest.writer.indexOf(tag), 1)
    },
    AreaHandleClose(tag) {
      this.ArticleRequest.area.splice(this.ArticleRequest.area.indexOf(tag), 1)
    },
    KeywordHandleClose(tag) {
      this.ArticleRequest.keyword.splice(this.ArticleRequest.keyword.indexOf(tag), 1)
    },
    AuthorTagShowInput() {
      this.AuthorInputVisible = true
      this.$nextTick(_ => {
        this.$refs.AuthorTag.$refs.input.focus()
      })
    },
    KeywordTagShowInput() {
      this.KeywordInputVisible = true
      this.$nextTick(_ => {
        this.$refs.KeywordTag.$refs.input.focus()
      })
    },
    AuthorHandleInputConfirm() {
      let AuthorInputValue = this.AuthorInputValue
      if (AuthorInputValue) {
        var values = AuthorInputValue.split(/[,， \n]/).filter(item => {
          return item !== '' && item !== undefined
        })
        values.forEach(element => {
          var index = this.ArticleRequest.writer.findIndex(i => {
            return i === element
          })
          if (index < 0) {
            this.ArticleRequest.writer.push(element)
          }
        })
      }
      this.AuthorInputVisible = false
      this.AuthorInputValue = ''
    },
    KeywordHandleInputConfirm() {
      let KeywordInputValue = this.KeywordInputValue
      if (KeywordInputValue) {
        var values = KeywordInputValue.split(/[,， \n]/).filter(item => {
          return item !== '' && item !== undefined
        })
        values.forEach(element => {
          var index = this.ArticleRequest.keyword.findIndex(i => {
            return i === element
          })
          if (index < 0) {
            this.ArticleRequest.keyword.push(element)
          }
        })
      }
      this.KeywordInputVisible = false
      this.KeywordInputValue = ''
    },
    PushArea() {
      this.ArticleRequest.area.push(this.AreaValueTmp[this.AreaValueTmp.length - 1])
    }
  }
}
</script>

<style lang="less" scoped>
.frame {
  margin-left: 20px;
  margin-right: 20px;
  .title {
    margin-top: 20px;
    font-size: 16px;
  }
  .el-tag {
    margin-right: 10px;
  }
  .el-tag + .el-tag {
    margin-right: 10px;
  }
  .button-new-tag {
    height: 32px;
    line-height: 30px;
    padding-top: 0;
    padding-bottom: 0;
  }
  .input-new-tag {
    vertical-align: bottom;
  }
}
</style>
