<template>
  <div>
    <div class="markdown-body">
      <VueMarkdown :source="mdData" v-highlight></VueMarkdown>
    </div>
  </div>
</template>

<script>
import VueMarkdown from 'vue-markdown'
export default {
  components: {
    VueMarkdown
  },
  data() {
    return {
      mdData: '',
      ArticleId: 0,
      Articles: {

      }
    }
  },
  created() {
    window.myData = this
    this.ArticleId = this.$store.state.ArticleId
    this.GetMetaArticle()
    this.TrueToMD()
  },
  methods: {
    GetMetaArticle () {
      this.$api.markdown.GetMetaArticle(this.ArticleId).then(res => {
        this.$message.success('获取元数据成功')
        this.Articles = res
      })
    },
    TrueToMD () {
      this.$router(this.Articles.url)
    }
  }
}
</script>

<style lang="less" scoped>

</style>
