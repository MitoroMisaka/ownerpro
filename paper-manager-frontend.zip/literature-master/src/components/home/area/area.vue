<template>
  <div class="main">
    <el-tree
      class="tree"
      :data="AreaData"
      node-key="id"
      default-expand-all
      @node-drag-start="handleDragStart"
      @node-drag-enter="handleDragEnter"
      @node-drag-leave="handleDragLeave"
      @node-drag-over="handleDragOver"
      @node-drag-end="handleDragEnd"
      @node-drop="handleDrop"
      draggable
      :allow-drop="allowDrop"
      :allow-drag="allowDrag">
      <span class="custom-tree-node" slot-scope="{ node, AreaData }">
        <span>{{ node.label }}</span>
        <span>
          <el-button
            type="text"
            @click="() => append(AreaData)">
            Append
          </el-button>
          <el-button
            type="text"
            @click="() => remove(node, AreaData)">
            Delete
          </el-button>
        </span>
      </span>
    </el-tree>
  </div>
</template>

<script>
export default {
  name: 'Area',
  data () {
    return {
      AreaData: [],
      TmpAreaData: [],
      TmpSecAreaItem: {
        id: '',
        label: '',
        children: []
      },
      TmpFirAreaItem: {
        id: '',
        label: '',
        children: []
      }
    }
  },
  created() {
    window.myData = this
    this.GetAllArea()
  },
  methods: {
    GetAllArea() {
      this.$api.area.GetAllArea().then(res => {
        this.TmpAreaData = res
        this.ToAreaTree()
      })
    },
    ToAreaTree() {
      for (let i = 0; i < this.TmpAreaData.length; i++) {
        this.TmpFirAreaItem.children.splice(0, this.TmpFirAreaItem.children.length)
        for (let j = 0; j < this.TmpAreaData[i].subAreas.length; j++) {
          this.TmpSecAreaItem.children.splice(0, this.TmpSecAreaItem.children.length)
          for (let k = 0; k < this.TmpAreaData[i].subAreas[j].subAreas.length; k++) {
            let id = this.TmpAreaData[i].subAreas[j].subAreas[k].area_id
            let label = this.TmpAreaData[i].subAreas[j].subAreas[k].name
            this.TmpSecAreaItem.children.push({ id: id, label: label })
          }
          this.TmpSecAreaItem.id = this.TmpAreaData[i].subAreas[j].area_id
          this.TmpSecAreaItem.label = this.TmpAreaData[i].subAreas[j].name
          this.TmpFirAreaItem.children.push(JSON.parse(JSON.stringify(this.TmpSecAreaItem)))
        }
        this.TmpFirAreaItem.id = this.TmpAreaData[i].id
        this.TmpFirAreaItem.label = this.TmpAreaData[i].name
        this.AreaData.push(JSON.parse(JSON.stringify(this.TmpFirAreaItem)))
      }
    },
    handleDragStart(node, ev) {
      console.log('drag start', node)
    },
    handleDragEnter(draggingNode, dropNode, ev) {
      console.log('tree drag enter: ', dropNode.label)
    },
    handleDragLeave(draggingNode, dropNode, ev) {
      console.log('tree drag leave: ', dropNode.label)
    },
    handleDragOver(draggingNode, dropNode, ev) {
      console.log('tree drag over: ', dropNode.label)
    },
    handleDragEnd(draggingNode, dropNode, dropType, ev) {
      console.log('tree drag end: ', dropNode && dropNode.label, dropType)
    },
    handleDrop(draggingNode, dropNode, dropType, ev) {
      console.log('tree drop: ', dropNode.label, dropType)
    },
    allowDrop(draggingNode, dropNode, type) {
      if (dropNode.data.label === '二级 3-1') {
        return type !== 'inner'
      } else {
        return true
      }
    },
    allowDrag(draggingNode) {
      return draggingNode.data.label.indexOf('三级 3-2-2') === -1
    },
    append(AreaData) {
      const newChild = { id: id++, label: 'testtest', children: [] }
      if (!AreaData.children) {
        this.$set(AreaData, 'children', [])
      }
      AreaData.children.push(newChild)
    },
    remove(node, AreaData) {
      const parent = node.parent
      const children = parent.AreaData.children || parent.AreaData
      const index = children.findIndex(d => d.id === AreaData.id)
      children.splice(index, 1)
    }
  }
}
</script>

<style lang="less" scoped>
  .main {
    margin-left: 0%;
    margin-right: 50%;
    .custom-tree-node {
      flex: 1;
      display: flex;
      align-items: center;
      justify-content: space-between;
      font-size: 20px;
      line-height: 2em;
      padding-right: 8px;
    }
  }
</style>
