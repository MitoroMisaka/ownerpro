export default {
  pathName: '', // 路由
  normalSearchContent: '', // 当前普通搜索内容
  Advanced: {
    content: '',
    label: '',
    label_content: [],
    pageSize: 13,
    pageNum: 1,
    orderBy: 'date desc'
  }, // 当前高级搜索内容
  pdfUrl: '', // 当前PDF的URL
  token: '', // token
  ArticleId: 0, // 当前MarkDown的Article_Id
  NoteId: 0, // 当前MarkDown的Note_Id
  Username: '', // 当前用户名
  Nickname: '', // 当前昵称
  Authority: 0, // 当前用户类别
  Operation: '' // 当前增删改查的操作
}
