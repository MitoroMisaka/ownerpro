<template>
  <div>
    <mavon-editor :ishljs="true" v-model="noteRequest.content" ref="md" @save="save" @imgAdd="imgAdd" />
  </div>
</template>
<script>
import { mavonEditor } from 'mavon-editor'
import 'mavon-editor/dist/css/index.css'
export default {
  name: 'AddNote',
  data () {
    return {
      noteRequest: {
        article_id: 0,
        content: ''
      }
    }
  },
  created() {
    window.myData = this
    this.noteRequest.article_id = this.$store.state.ArticleId
  },
  methods: {
    // 保存md到后台
    save() {
      this.$api.markdown.postMD(this.noteRequest).then(res => {
        if (res.status !== 0) {
          return this.$message.error('上传失败')
        }
        this.$message.success('上传成功')
        this.dialogFormVisible = false
      })
    },
    // 保存图片到后台
    imgAdd(pos, $file) {
      // 第一步.将图片上传到服务器.
      var formdata = new FormData()
      formdata.append('multipartFile', $file)
      this.$api.markdown.uploadFile(formdata).then(res => {
        var url = res.data // 取出上传成功后的url
        // url = 'http://localhost:8080/api/' + url.substring(22)
        if (res.status === 0) {
          //  将后端返回的url放在md中图片的指定位置
          console.log(url)
          this.$refs.md.$img2Url(pos, url)
        } else {
          this.$message('图片上传失败')
        }
      })
    }
  },
  components: {
    mavonEditor
  }
}
</script>
